export type HttpMethod = 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';

export type AuthType = 'None' | 'Bearer Token' | 'API Key';

export interface ApiParameter {
  name: string;
  in: 'query' | 'path' | 'header' | 'body';
  type: string;
  required: boolean;
  description: string;
  example?: string;
  default?: string;
}

export interface ApiResponseExample {
  status: number;
  label: string;
  description: string;
  body: Record<string, unknown> | Array<unknown>;
}

export interface ApiEndpoint {
  id: string;
  category: 'Users' | 'Posts' | 'Products' | 'Authentication' | 'Utilities';
  title: string;
  method: HttpMethod;
  path: string;
  summary: string;
  description: string;
  auth: AuthType;
  rateLimit: string;
  parameters?: ApiParameter[];
  requestBody?: {
    required: boolean;
    contentType: string;
    schema: Record<string, unknown>;
    example: Record<string, unknown>;
  };
  responses: ApiResponseExample[];
  tags: string[];
}

export const API_CATEGORIES = [
  { id: 'all', name: 'All Categories', count: 14 },
  { id: 'Users', name: 'Users', count: 5, description: 'Manage user profiles, credentials, and roles' },
  { id: 'Posts', name: 'Posts', count: 3, description: 'Articles, markdown content, and publish status' },
  { id: 'Products', name: 'Products', count: 2, description: 'Commerce inventory, SKUs, pricing, and tags' },
  { id: 'Authentication', name: 'Authentication', count: 2, description: 'Token generation, session verification, scopes' },
  { id: 'Utilities', name: 'Utilities', count: 2, description: 'Health checks, echo testing, and quota inspection' },
] as const;

export const API_ENDPOINTS: ApiEndpoint[] = [
  {
    id: 'get-users',
    category: 'Users',
    title: 'List Users',
    method: 'GET',
    path: '/api/v1/users',
    summary: 'Retrieve a paginated list of registered users with optional role filtering.',
    description: 'Returns a list of user objects ordered by creation date descending. Supports cursor and page-based pagination along with role and status filtering.',
    auth: 'None',
    rateLimit: '120 req/min',
    tags: ['users', 'pagination', 'directory'],
    parameters: [
      { name: 'page', in: 'query', type: 'integer', required: false, description: 'Page number for pagination', default: '1', example: '1' },
      { name: 'limit', in: 'query', type: 'integer', required: false, description: 'Number of records per page (max 50)', default: '10', example: '10' },
      { name: 'role', in: 'query', type: 'string', required: false, description: 'Filter by account role', example: 'developer' },
      { name: 'search', in: 'query', type: 'string', required: false, description: 'Search query matching name or email', example: 'alex' }
    ],
    responses: [
      {
        status: 200,
        label: '200 OK',
        description: 'Successfully retrieved user list.',
        body: {
          success: true,
          meta: {
            page: 1,
            limit: 10,
            total: 24,
            totalPages: 3
          },
          data: [
            {
              id: 'usr_001',
              name: 'Alex Morgan',
              email: 'alex@example.com',
              role: 'lead_architect',
              status: 'active',
              createdAt: '2026-03-12T08:14:20Z'
            },
            {
              id: 'usr_002',
              name: 'Sarah Chen',
              email: 'sarah.chen@devcorp.io',
              role: 'systems_engineer',
              status: 'active',
              createdAt: '2026-04-01T12:00:15Z'
            },
            {
              id: 'usr_003',
              name: 'Dmitri Volkov',
              email: 'dmitri@binarystack.net',
              role: 'developer',
              status: 'pending',
              createdAt: '2026-05-18T19:42:01Z'
            }
          ]
        }
      },
      {
        status: 400,
        label: '400 Bad Request',
        description: 'Invalid query parameters provided.',
        body: {
          success: false,
          error: {
            code: 'INVALID_QUERY_PARAMETER',
            message: 'Parameter "limit" must be an integer between 1 and 50.',
            timestamp: '2026-10-17T14:15:00Z'
          }
        }
      }
    ]
  },
  {
    id: 'get-user-by-id',
    category: 'Users',
    title: 'Get User by ID',
    method: 'GET',
    path: '/api/v1/users/{id}',
    summary: 'Retrieve detailed information for a specific user account.',
    description: 'Retrieves complete profile details for the provided user ID including metadata, tier, and permission scopes.',
    auth: 'None',
    rateLimit: '120 req/min',
    tags: ['users', 'profile', 'lookup'],
    parameters: [
      { name: 'id', in: 'path', type: 'string', required: true, description: 'Unique identifier of the user (e.g. usr_001)', example: 'usr_001' }
    ],
    responses: [
      {
        status: 200,
        label: '200 OK',
        description: 'User found and returned.',
        body: {
          success: true,
          data: {
            id: 'usr_001',
            name: 'Alex Morgan',
            email: 'alex@example.com',
            role: 'lead_architect',
            tier: 'enterprise',
            status: 'active',
            timezone: 'UTC',
            verified: true,
            createdAt: '2026-03-12T08:14:20Z',
            lastLoginAt: '2026-10-17T09:30:11Z'
          }
        }
      },
      {
        status: 404,
        label: '404 Not Found',
        description: 'User ID does not exist in the platform.',
        body: {
          success: false,
          error: {
            code: 'USER_NOT_FOUND',
            message: 'No active user found with identifier "usr_999".',
            timestamp: '2026-10-17T14:15:00Z'
          }
        }
      }
    ]
  },
  {
    id: 'create-user',
    category: 'Users',
    title: 'Create User',
    method: 'POST',
    path: '/api/v1/users',
    summary: 'Provision a new developer user profile on the platform.',
    description: 'Creates a new user record. Requires a valid email address and profile name. Automatically creates a default sandbox workspace.',
    auth: 'Bearer Token',
    rateLimit: '30 req/min',
    tags: ['users', 'provisioning'],
    parameters: [
      { name: 'Authorization', in: 'header', type: 'string', required: true, description: 'Bearer access token format: Bearer <token>', example: 'Bearer rsp_live_89a12c4' }
    ],
    requestBody: {
      required: true,
      contentType: 'application/json',
      schema: {
        name: 'string (min 2, max 64)',
        email: 'string (valid email format)',
        role: 'string (developer | admin | architect)'
      },
      example: {
        name: 'Elena Rostova',
        email: 'elena@deepkernel.dev',
        role: 'developer'
      }
    },
    responses: [
      {
        status: 201,
        label: '201 Created',
        description: 'User successfully created.',
        body: {
          success: true,
          data: {
            id: 'usr_004',
            name: 'Elena Rostova',
            email: 'elena@deepkernel.dev',
            role: 'developer',
            status: 'active',
            createdAt: '2026-10-17T14:20:00Z'
          }
        }
      },
      {
        status: 400,
        label: '400 Bad Request',
        description: 'Missing or malformed payload fields.',
        body: {
          success: false,
          error: {
            code: 'VALIDATION_FAILED',
            message: 'Field "email" must be a valid RFC 5322 compliant address.',
            timestamp: '2026-10-17T14:20:00Z'
          }
        }
      },
      {
        status: 401,
        label: '401 Unauthorized',
        description: 'Missing or invalid authentication header.',
        body: {
          success: false,
          error: {
            code: 'AUTHENTICATION_REQUIRED',
            message: 'A valid Bearer token is required to create resources.',
            timestamp: '2026-10-17T14:20:00Z'
          }
        }
      }
    ]
  },
  {
    id: 'update-user',
    category: 'Users',
    title: 'Update User Profile',
    method: 'PUT',
    path: '/api/v1/users/{id}',
    summary: 'Update attributes of an existing user profile.',
    description: 'Replaces mutable fields of a user record. Unspecified fields will retain their current state.',
    auth: 'Bearer Token',
    rateLimit: '30 req/min',
    tags: ['users', 'profile', 'mutate'],
    parameters: [
      { name: 'id', in: 'path', type: 'string', required: true, description: 'Unique user identifier', example: 'usr_001' }
    ],
    requestBody: {
      required: true,
      contentType: 'application/json',
      schema: {
        name: 'string (optional)',
        role: 'string (optional)'
      },
      example: {
        name: 'Alex Morgan-Vance',
        role: 'principal_architect'
      }
    },
    responses: [
      {
        status: 200,
        label: '200 OK',
        description: 'Profile updated successfully.',
        body: {
          success: true,
          data: {
            id: 'usr_001',
            name: 'Alex Morgan-Vance',
            email: 'alex@example.com',
            role: 'principal_architect',
            updatedAt: '2026-10-17T14:21:00Z'
          }
        }
      }
    ]
  },
  {
    id: 'delete-user',
    category: 'Users',
    title: 'Delete User Account',
    method: 'DELETE',
    path: '/api/v1/users/{id}',
    summary: 'Permanently remove a user and invalidate associated API sessions.',
    description: 'Deletes the specified user account. Irreversible action. Requires admin scope.',
    auth: 'Bearer Token',
    rateLimit: '20 req/min',
    tags: ['users', 'destructive'],
    parameters: [
      { name: 'id', in: 'path', type: 'string', required: true, description: 'User ID to terminate', example: 'usr_003' }
    ],
    responses: [
      {
        status: 200,
        label: '200 OK',
        description: 'User successfully deleted.',
        body: {
          success: true,
          data: {
            id: 'usr_003',
            deleted: true,
            timestamp: '2026-10-17T14:22:00Z'
          }
        }
      }
    ]
  },
  {
    id: 'get-posts',
    category: 'Posts',
    title: 'List Content Posts',
    method: 'GET',
    path: '/api/v1/posts',
    summary: 'Query articles, documentation changelogs, and published posts.',
    description: 'Fetches published markdown posts with tag filters, author attribution, and read-time estimates.',
    auth: 'None',
    rateLimit: '120 req/min',
    tags: ['posts', 'content', 'markdown'],
    parameters: [
      { name: 'tag', in: 'query', type: 'string', required: false, description: 'Filter by category tag (e.g. engineering)', example: 'engineering' },
      { name: 'limit', in: 'query', type: 'integer', required: false, description: 'Max items to return', default: '10', example: '5' }
    ],
    responses: [
      {
        status: 200,
        label: '200 OK',
        description: 'List of published posts.',
        body: {
          success: true,
          data: [
            {
              id: 'pst_101',
              title: 'Building Predictable REST Contracts with Zero Drift',
              slug: 'building-predictable-rest-contracts',
              author: 'Alex Morgan',
              tag: 'engineering',
              readingTime: '5 min',
              publishedAt: '2026-09-28T10:00:00Z'
            },
            {
              id: 'pst_102',
              title: 'Migrating Edge CDN Gateways with Sub-5ms TLS Handshakes',
              slug: 'migrating-edge-cdn-gateways',
              author: 'Sarah Chen',
              tag: 'infrastructure',
              readingTime: '8 min',
              publishedAt: '2026-10-04T16:30:00Z'
            }
          ]
        }
      }
    ]
  },
  {
    id: 'get-post-by-id',
    category: 'Posts',
    title: 'Get Post by ID',
    method: 'GET',
    path: '/api/v1/posts/{id}',
    summary: 'Retrieve full article content and markdown payload.',
    description: 'Returns the full body, frontmatter attributes, and view analytics of a single post.',
    auth: 'None',
    rateLimit: '120 req/min',
    tags: ['posts', 'lookup'],
    parameters: [
      { name: 'id', in: 'path', type: 'string', required: true, description: 'Post ID (e.g. pst_101)', example: 'pst_101' }
    ],
    responses: [
      {
        status: 200,
        label: '200 OK',
        description: 'Post details found.',
        body: {
          success: true,
          data: {
            id: 'pst_101',
            title: 'Building Predictable REST Contracts with Zero Drift',
            content: 'REST APIs remain the bedrock of distributed system design...',
            author: 'Alex Morgan',
            tag: 'engineering',
            views: 4210,
            publishedAt: '2026-09-28T10:00:00Z'
          }
        }
      }
    ]
  },
  {
    id: 'create-post',
    category: 'Posts',
    title: 'Publish New Post',
    method: 'POST',
    path: '/api/v1/posts',
    summary: 'Publish a new technical post or changelog entry.',
    description: 'Creates a new post entry with automated slug generation and syntax formatting.',
    auth: 'Bearer Token',
    rateLimit: '30 req/min',
    tags: ['posts', 'publish'],
    requestBody: {
      required: true,
      contentType: 'application/json',
      schema: {
        title: 'string (min 5)',
        content: 'string (markdown)',
        tag: 'string'
      },
      example: {
        title: 'Architecting Resilient API Pipelines',
        content: 'In this article we break down the retry policies...',
        tag: 'architecture'
      }
    },
    responses: [
      {
        status: 201,
        label: '201 Created',
        description: 'Post published successfully.',
        body: {
          success: true,
          data: {
            id: 'pst_103',
            title: 'Architecting Resilient API Pipelines',
            slug: 'architecting-resilient-api-pipelines',
            tag: 'architecture',
            status: 'published',
            publishedAt: '2026-10-17T14:24:00Z'
          }
        }
      }
    ]
  },
  {
    id: 'get-products',
    category: 'Products',
    title: 'List Products',
    method: 'GET',
    path: '/api/v1/products',
    summary: 'Query store catalog items with stock levels, currency, and categories.',
    description: 'Returns product catalog entries with stock status, pricing in USD, and SKU identifiers.',
    auth: 'None',
    rateLimit: '120 req/min',
    tags: ['products', 'catalog', 'commerce'],
    parameters: [
      { name: 'category', in: 'query', type: 'string', required: false, description: 'Category filter', example: 'hardware' },
      { name: 'inStock', in: 'query', type: 'boolean', required: false, description: 'Only show items currently in stock', example: 'true' }
    ],
    responses: [
      {
        status: 200,
        label: '200 OK',
        description: 'Product list retrieved.',
        body: {
          success: true,
          data: [
            {
              id: 'prd_901',
              sku: 'HW-MOD-GATE-01',
              name: 'Edge Gateway Appliance V2',
              category: 'hardware',
              price: 499.00,
              currency: 'USD',
              stock: 42,
              inStock: true
            },
            {
              id: 'prd_902',
              sku: 'SW-LIC-CLUSTER-ENT',
              name: 'Enterprise Cluster License (1 Year)',
              category: 'software',
              price: 2400.00,
              currency: 'USD',
              stock: 9999,
              inStock: true
            }
          ]
        }
      }
    ]
  },
  {
    id: 'get-product-by-id',
    category: 'Products',
    title: 'Get Product by SKU or ID',
    method: 'GET',
    path: '/api/v1/products/{id}',
    summary: 'Lookup a single product item by identifier.',
    description: 'Retrieves pricing tiers, warehouse availability, and technical specifications.',
    auth: 'None',
    rateLimit: '120 req/min',
    tags: ['products', 'lookup'],
    parameters: [
      { name: 'id', in: 'path', type: 'string', required: true, description: 'Product ID or SKU', example: 'prd_901' }
    ],
    responses: [
      {
        status: 200,
        label: '200 OK',
        description: 'Product details returned.',
        body: {
          success: true,
          data: {
            id: 'prd_901',
            sku: 'HW-MOD-GATE-01',
            name: 'Edge Gateway Appliance V2',
            description: 'Low-latency rackmount hardware gateway with dual 10GbE SFP+ uplinks.',
            category: 'hardware',
            price: 499.00,
            currency: 'USD',
            stock: 42,
            inStock: true,
            dimensions: { weightKg: 2.4, rackUnits: 1 }
          }
        }
      }
    ]
  },
  {
    id: 'create-auth-token',
    category: 'Authentication',
    title: 'Generate Access Token',
    method: 'POST',
    path: '/api/v1/auth/tokens',
    summary: 'Issue an OAuth2 / Bearer JWT access token using client credentials.',
    description: 'Exchange your Client ID and Client Secret for an access token with specified scopes.',
    auth: 'API Key',
    rateLimit: '20 req/min',
    tags: ['auth', 'jwt', 'security'],
    requestBody: {
      required: true,
      contentType: 'application/json',
      schema: {
        clientId: 'string',
        clientSecret: 'string',
        scopes: 'array of strings (e.g. ["read:users", "write:posts"])'
      },
      example: {
        clientId: 'client_live_demo_987',
        clientSecret: 'sec_k89a12c4e7f800b21a',
        scopes: ['read:users', 'write:posts']
      }
    },
    responses: [
      {
        status: 200,
        label: '200 OK',
        description: 'Access token generated successfully.',
        body: {
          success: true,
          data: {
            tokenType: 'Bearer',
            accessToken: 'rsp_tok_99fa71b8e0192ca5439a0',
            expiresIn: 3600,
            scopes: ['read:users', 'write:posts'],
            issuedAt: '2026-10-17T14:25:00Z'
          }
        }
      },
      {
        status: 401,
        label: '401 Unauthorized',
        description: 'Client credentials incorrect or revoked.',
        body: {
          success: false,
          error: {
            code: 'INVALID_CREDENTIALS',
            message: 'Client credentials could not be verified against the credential registry.',
            timestamp: '2026-10-17T14:25:00Z'
          }
        }
      }
    ]
  },
  {
    id: 'verify-auth',
    category: 'Authentication',
    title: 'Verify Token Claims',
    method: 'GET',
    path: '/api/v1/auth/verify',
    summary: 'Introspect active token scopes, expiration, and identity context.',
    description: 'Returns the decoded claims, remaining TTL, and permission matrix for an Authorization header.',
    auth: 'Bearer Token',
    rateLimit: '60 req/min',
    tags: ['auth', 'introspect'],
    parameters: [
      { name: 'Authorization', in: 'header', type: 'string', required: true, description: 'Bearer <token>', example: 'Bearer rsp_tok_99fa71b8e0192ca5439a0' }
    ],
    responses: [
      {
        status: 200,
        label: '200 OK',
        description: 'Token verified successfully.',
        body: {
          success: true,
          data: {
            active: true,
            clientId: 'client_live_demo_987',
            scopes: ['read:users', 'write:posts'],
            expiresAt: '2026-10-17T15:25:00Z',
            environment: 'production'
          }
        }
      }
    ]
  },
  {
    id: 'ping-utility',
    category: 'Utilities',
    title: 'Ping Gateway & Latency',
    method: 'GET',
    path: '/api/v1/utilities/ping',
    summary: 'High-speed diagnostic endpoint to verify network latency and service liveness.',
    description: 'Returns server timestamp, edge region identifier, and runtime status with zero database overhead.',
    auth: 'None',
    rateLimit: '300 req/min',
    tags: ['utilities', 'health', 'diagnostics'],
    parameters: [],
    responses: [
      {
        status: 200,
        label: '200 OK',
        description: 'Ping response returned with edge diagnostics.',
        body: {
          success: true,
          status: 'ok',
          pong: true,
          serverTime: '2026-10-17T14:26:00.120Z',
          region: 'sin1-sg',
          version: '1.4.0',
          uptimeSeconds: 842109
        }
      }
    ]
  },
  {
    id: 'echo-utility',
    category: 'Utilities',
    title: 'Echo Request Inspector',
    method: 'POST',
    path: '/api/v1/utilities/echo',
    summary: 'Echo back headers, body payload, and connection metadata.',
    description: 'Helpful for inspecting HTTP client behavior, debugging proxies, and validating serialization.',
    auth: 'None',
    rateLimit: '60 req/min',
    tags: ['utilities', 'echo', 'debugging'],
    requestBody: {
      required: false,
      contentType: 'application/json',
      schema: {
        payload: 'any JSON object'
      },
      example: {
        message: 'Hello Resp API',
        environment: 'development',
        timestamp: 1729175160
      }
    },
    responses: [
      {
        status: 200,
        label: '200 OK',
        description: 'Echo payload returned.',
        body: {
          success: true,
          echo: {
            method: 'POST',
            path: '/api/v1/utilities/echo',
            receivedAt: '2026-10-17T14:26:15Z',
            body: {
              message: 'Hello Resp API',
              environment: 'development'
            }
          }
        }
      }
    ]
  }
];
