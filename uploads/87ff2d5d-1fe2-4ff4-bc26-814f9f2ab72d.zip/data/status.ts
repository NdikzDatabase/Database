export type ServiceStatus = 'operational' | 'degraded' | 'outage' | 'maintenance';

export interface ServiceComponent {
  name: string;
  category: string;
  status: ServiceStatus;
  uptime: string;
  latency: string;
  description: string;
}

export interface StatusIncident {
  id: string;
  title: string;
  status: 'resolved' | 'monitoring' | 'identified' | 'investigating';
  severity: 'minor' | 'major' | 'critical' | 'maintenance';
  impact: string;
  createdAt: string;
  resolvedAt?: string;
  updates: {
    timestamp: string;
    status: string;
    message: string;
  }[];
}

export interface DayUptime {
  date: string;
  uptime: number;
  status: ServiceStatus;
}

export const STATUS_COMPONENTS: ServiceComponent[] = [
  {
    name: 'REST API Gateway (Edge Routing)',
    category: 'Core Infrastructure',
    status: 'operational',
    uptime: '99.99%',
    latency: '14ms',
    description: 'Anycast DNS edge proxies handling HTTP/1.1 and HTTP/2 TLS handshakes'
  },
  {
    name: 'Authentication & Token Issuer',
    category: 'Security & Identity',
    status: 'operational',
    uptime: '100%',
    latency: '22ms',
    description: 'Bearer token verification, HMAC secret signing, and OAuth2 validation'
  },
  {
    name: 'Users & Profile Service',
    category: 'Domain APIs',
    status: 'operational',
    uptime: '99.98%',
    latency: '18ms',
    description: 'User record serialization, database reads, and directory filtering'
  },
  {
    name: 'Content & Posts Service',
    category: 'Domain APIs',
    status: 'operational',
    uptime: '100%',
    latency: '16ms',
    description: 'Markdown articles cache, tag indexing, and read-time metadata'
  },
  {
    name: 'Products & Commerce Service',
    category: 'Domain APIs',
    status: 'operational',
    uptime: '99.96%',
    latency: '20ms',
    description: 'SKU lookup engine, price calculations, and stock verification'
  },
  {
    name: 'Webhook Dispatcher & Queue',
    category: 'Messaging',
    status: 'operational',
    uptime: '99.94%',
    latency: '45ms',
    description: 'Asynchronous event emission, retry backoff scheduler, and delivery receipts'
  }
];

export const STATUS_INCIDENTS: StatusIncident[] = [
  {
    id: 'inc_8402',
    title: 'Elevated Latency on Edge Routing in AP-East',
    status: 'resolved',
    severity: 'minor',
    impact: 'Minor latency degradation for users routing through Hong Kong edge nodes',
    createdAt: '2026-10-09T03:14:00Z',
    resolvedAt: '2026-10-09T04:02:00Z',
    updates: [
      {
        timestamp: '2026-10-09T04:02:00Z',
        status: 'Resolved',
        message: 'Upstream transit fiber provider resolved link flap. Traffic normalized across all primary nodes.'
      },
      {
        timestamp: '2026-10-09T03:30:00Z',
        status: 'Monitoring',
        message: 'Traffic re-routed to Singapore and Tokyo edge clusters. Latency metrics returned below 25ms threshold.'
      },
      {
        timestamp: '2026-10-09T03:14:00Z',
        status: 'Investigating',
        message: 'Engineers are investigating packet jitter reported by edge telemetry in the Asia-Pacific East sector.'
      }
    ]
  },
  {
    id: 'maint_8390',
    title: 'Scheduled Database Primary Index Optimization',
    status: 'resolved',
    severity: 'maintenance',
    impact: 'No downtime; zero dropped connections observed',
    createdAt: '2026-09-24T01:00:00Z',
    resolvedAt: '2026-09-24T01:45:00Z',
    updates: [
      {
        timestamp: '2026-09-24T01:45:00Z',
        status: 'Completed',
        message: 'Online index rebuild completed successfully across all read replicas.'
      },
      {
        timestamp: '2026-09-24T01:00:00Z',
        status: 'In Progress',
        message: 'Beginning rolling index defragmentation on primary database nodes.'
      }
    ]
  }
];

// Generate 90 days of uptime history for visualization
export function getUptimeHistory(): DayUptime[] {
  const days: DayUptime[] = [];
  const now = new Date('2026-10-17T12:00:00Z');

  for (let i = 89; i >= 0; i--) {
    const d = new Date(now);
    d.setDate(d.getDate() - i);
    const dateStr = d.toISOString().split('T')[0];

    // Simulate occasional minor incidents in the past for realistic monitoring data
    let uptime = 100;
    let status: ServiceStatus = 'operational';

    if (i === 8) {
      uptime = 99.72;
      status = 'degraded';
    } else if (i === 23) {
      uptime = 99.88;
      status = 'operational';
    } else if (i === 56) {
      uptime = 99.91;
      status = 'operational';
    }

    days.push({
      date: dateStr,
      uptime,
      status
    });
  }

  return days;
}
