export interface ChangelogEntry {
  version: string;
  date: string;
  title: string;
  summary: string;
  type: 'major' | 'minor' | 'patch';
  changes: {
    category: 'Features' | 'Improvements' | 'Fixes' | 'Security';
    items: string[];
  }[];
}

export const CHANGELOG_DATA: ChangelogEntry[] = [
  {
    version: 'v1.4.0',
    date: 'October 12, 2026',
    title: 'Cursor Pagination & Granular Rate-Limit Headers',
    summary: 'Introduced cursor-based pagination across high-throughput collections, upgraded standard IETF rate-limit response headers, and added the /api/v1/utilities/echo diagnostic route.',
    type: 'minor',
    changes: [
      {
        category: 'Features',
        items: [
          'Added cursor-based pagination via ?starting_after and ?ending_before on /api/v1/users.',
          'Added /api/v1/utilities/echo diagnostic tool for inspecting client request serialization.',
          'Added automatic OpenAPI 3.1 schema export downloadable via developer console.'
        ]
      },
      {
        category: 'Improvements',
        items: [
          'Standardized RateLimit-Limit, RateLimit-Remaining, and RateLimit-Reset headers across all endpoints.',
          'Reduced payload serialization overhead by 22% using pre-compiled JSON schemas.',
          'Optimized database index lookups for user role and status filters.'
        ]
      },
      {
        category: 'Fixes',
        items: [
          'Fixed 404 response payload consistency when querying nonexistent UUID slugs.',
          'Resolved an edge-case where trailing slashes caused 308 permanent redirect loops in strict HTTP clients.'
        ]
      }
    ]
  },
  {
    version: 'v1.3.2',
    date: 'September 20, 2026',
    title: 'Webhook Replay Protection & Signature Upgrades',
    summary: 'Hardened webhook dispatching mechanisms with HMAC-SHA256 signatures, exponential backoff retries, and comprehensive delivery logs.',
    type: 'patch',
    changes: [
      {
        category: 'Security',
        items: [
          'Introduced X-Resp-Signature-256 header with timestamp validation to prevent replay attacks.',
          'Enforced TLS 1.3 requirement for all production webhook endpoints.'
        ]
      },
      {
        category: 'Improvements',
        items: [
          'Added automatic webhook retry strategy with jittered exponential backoff over 72 hours.',
          'Expanded error response objects to include machine-readable machine_code and documentation links.'
        ]
      },
      {
        category: 'Fixes',
        items: [
          'Corrected content-type negotiation when clients send Accept: application/vnd.api+json.'
        ]
      }
    ]
  },
  {
    version: 'v1.2.0',
    date: 'August 14, 2026',
    title: 'Commerce Products Catalog & Inventory Control',
    summary: 'Expanded Resp API domain coverage with the Products suite, supporting SKU tracking, multi-currency price structures, and stock availability queries.',
    type: 'minor',
    changes: [
      {
        category: 'Features',
        items: [
          'Added /api/v1/products and /api/v1/products/{id} endpoints with SKU-based querying.',
          'Added support for filtering items by inStock boolean and category grouping.',
          'Introduced dimensional specifications and warehouse weight attributes in product details.'
        ]
      },
      {
        category: 'Improvements',
        items: [
          'Enhanced query performance for product listing with sub-15ms p99 latency at the edge.',
          'Added detailed parameter validation with inline field pointers on 400 Bad Request.'
        ]
      }
    ]
  },
  {
    version: 'v1.1.0',
    date: 'July 02, 2026',
    title: 'OAuth2 Client Credentials & Token Introspection',
    summary: 'Shipped secure token issuance via /api/v1/auth/tokens and instant token introspection with the /api/v1/auth/verify endpoint.',
    type: 'minor',
    changes: [
      {
        category: 'Security',
        items: [
          'Implemented Bearer JWT authorization model with configurable expiration windows.',
          'Added scope-based access enforcement for mutation endpoints (POST, PUT, DELETE).'
        ]
      },
      {
        category: 'Features',
        items: [
          'Added /api/v1/auth/tokens with client_credentials grant type support.',
          'Added /api/v1/auth/verify endpoint returning remaining TTL, issuer, and authorized scopes.'
        ]
      }
    ]
  },
  {
    version: 'v1.0.0',
    date: 'May 10, 2026',
    title: 'Resp API Initial Public Release',
    summary: 'The initial public release of Resp API platform. Featuring foundational REST endpoints, interactive documentation, zero-drift contracts, and global edge routing.',
    type: 'major',
    changes: [
      {
        category: 'Features',
        items: [
          'Core user management endpoints (/api/v1/users).',
          'Content publishing and articles endpoints (/api/v1/posts).',
          'Diagnostic latency check endpoint (/api/v1/utilities/ping).',
          'Interactive web documentation with multi-language code snippets.'
        ]
      }
    ]
  }
];
