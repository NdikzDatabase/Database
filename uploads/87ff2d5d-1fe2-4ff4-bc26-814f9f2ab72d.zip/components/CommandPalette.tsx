'use client';

import React, { useState, useEffect, useRef } from 'react';
import { useRouter } from 'next/navigation';
import { Search, Terminal, BookOpen, Layers, Activity, History, ArrowRight, CornerDownLeft } from 'lucide-react';
import { API_ENDPOINTS } from '@/data/endpoints';
import { MethodBadge } from './ui/MethodBadge';

interface CommandItem {
  id: string;
  title: string;
  subtitle?: string;
  category: 'Endpoints' | 'Navigation' | 'Documentation';
  href: string;
  method?: string;
  icon?: React.ReactNode;
}

export function CommandPalette() {
  const [isOpen, setIsOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const router = useRouter();

  // Keyboard shortcut listener (Ctrl+K / Cmd+K)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setIsOpen((prev) => !prev);
      } else if (e.key === 'Escape' && isOpen) {
        e.preventDefault();
        setIsOpen(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen]);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
      setSelectedIndex(0);
    } else {
      setQuery('');
    }
  }, [isOpen]);

  // Construct items
  const baseItems: CommandItem[] = [
    {
      id: 'nav-overview',
      title: 'Platform Overview',
      subtitle: 'Resp API landing and developer overview',
      category: 'Navigation',
      href: '/',
      icon: <Terminal className="w-4 h-4 text-[#818CF8]" />
    },
    {
      id: 'nav-explorer',
      title: 'API Explorer',
      subtitle: 'Browse all endpoints, schemas and parameters',
      category: 'Navigation',
      href: '/explorer',
      icon: <Layers className="w-4 h-4 text-[#818CF8]" />
    },
    {
      id: 'nav-docs',
      title: 'Documentation',
      subtitle: 'Technical guides, authentication, and SDKs',
      category: 'Documentation',
      href: '/docs',
      icon: <BookOpen className="w-4 h-4 text-[#67E8F9]" />
    },
    {
      id: 'nav-playground',
      title: 'API Playground',
      subtitle: 'Send real HTTP requests and inspect payloads',
      category: 'Navigation',
      href: '/playground',
      icon: <Terminal className="w-4 h-4 text-[#4ADE80]" />
    },
    {
      id: 'nav-changelog',
      title: 'Changelog',
      subtitle: 'Recent version releases and technical updates',
      category: 'Navigation',
      href: '/changelog',
      icon: <History className="w-4 h-4 text-[#9CA3AF]" />
    },
    {
      id: 'nav-status',
      title: 'System Status',
      subtitle: 'Component health and uptime telemetry',
      category: 'Navigation',
      href: '/status',
      icon: <Activity className="w-4 h-4 text-[#4ADE80]" />
    }
  ];

  const endpointItems: CommandItem[] = API_ENDPOINTS.map((ep) => ({
    id: `ep-${ep.id}`,
    title: ep.title,
    subtitle: ep.path,
    category: 'Endpoints',
    href: `/docs?endpoint=${ep.id}`,
    method: ep.method
  }));

  const allItems = [...baseItems, ...endpointItems];

  const filteredItems = query.trim() === ''
    ? allItems.slice(0, 8)
    : allItems.filter(
        (item) =>
          item.title.toLowerCase().includes(query.toLowerCase()) ||
          (item.subtitle && item.subtitle.toLowerCase().includes(query.toLowerCase())) ||
          (item.method && item.method.toLowerCase().includes(query.toLowerCase()))
      ).slice(0, 10);

  const handleSelect = (item: CommandItem) => {
    setIsOpen(false);
    router.push(item.href);
  };

  const handleKeyNavigation = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex((prev) => (prev + 1) % (filteredItems.length || 1));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex((prev) => (prev - 1 + filteredItems.length) % (filteredItems.length || 1));
    } else if (e.key === 'Enter' && filteredItems[selectedIndex]) {
      e.preventDefault();
      handleSelect(filteredItems[selectedIndex]);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 px-4">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-[#0B0D12]/80 backdrop-blur-sm transition-opacity"
        onClick={() => setIsOpen(false)}
      />

      {/* Modal Dialog */}
      <div
        role="dialog"
        aria-modal="true"
        aria-label="Command search palette"
        className="relative w-full max-w-xl rounded-lg border border-[#252A35] bg-[#10131A] shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150 z-10"
      >
        {/* Search Input Bar */}
        <div className="flex items-center px-4 py-3 border-b border-[#252A35] bg-[#0D1016]">
          <Search className="w-4 h-4 text-[#6B7280] mr-2.5 shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setSelectedIndex(0);
            }}
            onKeyDown={handleKeyNavigation}
            placeholder="Search endpoints, documentation, tools..."
            className="w-full bg-transparent text-sm text-[#ECEFF4] placeholder-[#6B7280] outline-none font-sans"
          />
          <kbd className="hidden sm:inline-block px-1.5 py-0.5 text-[10px] font-mono text-[#6B7280] bg-[#151923] border border-[#252A35] rounded">
            ESC
          </kbd>
        </div>

        {/* Results List */}
        <div className="max-h-80 overflow-y-auto p-2 divide-y divide-[#252A35]/30">
          {filteredItems.length === 0 ? (
            <div className="py-8 text-center text-xs text-[#6B7280]">
              No matching endpoints or guides found for &quot;{query}&quot;
            </div>
          ) : (
            filteredItems.map((item, index) => {
              const isSelected = index === selectedIndex;
              return (
                <div
                  key={item.id}
                  onClick={() => handleSelect(item)}
                  onMouseEnter={() => setSelectedIndex(index)}
                  className={`flex items-center justify-between px-3 py-2.5 rounded cursor-pointer transition-colors ${
                    isSelected ? 'bg-[#151923] text-[#ECEFF4]' : 'text-[#9CA3AF] hover:bg-[#151923]/60'
                  }`}
                >
                  <div className="flex items-center gap-2.5 overflow-hidden">
                    {item.method ? (
                      <MethodBadge method={item.method} size="sm" />
                    ) : (
                      <span className="shrink-0">{item.icon}</span>
                    )}
                    <div className="flex flex-col truncate">
                      <span className="text-xs font-medium text-[#ECEFF4] truncate">{item.title}</span>
                      {item.subtitle && (
                        <span className="text-[11px] font-mono text-[#6B7280] truncate">{item.subtitle}</span>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0 ml-3">
                    <span className="text-[10px] text-[#6B7280] font-sans border border-[#252A35] px-1.5 py-0.5 rounded bg-[#0B0D12]">
                      {item.category}
                    </span>
                    {isSelected && <CornerDownLeft className="w-3.5 h-3.5 text-[#818CF8]" />}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer info bar */}
        <div className="flex items-center justify-between px-4 py-2 border-t border-[#252A35] bg-[#0B0D12] text-[11px] text-[#6B7280]">
          <div className="flex items-center gap-3">
            <span className="inline-flex items-center gap-1">
              <kbd className="px-1 py-0.5 text-[9px] font-mono bg-[#151923] border border-[#252A35] rounded">↑</kbd>
              <kbd className="px-1 py-0.5 text-[9px] font-mono bg-[#151923] border border-[#252A35] rounded">↓</kbd>
              Navigate
            </span>
            <span className="inline-flex items-center gap-1">
              <kbd className="px-1 py-0.5 text-[9px] font-mono bg-[#151923] border border-[#252A35] rounded">↵</kbd>
              Select
            </span>
          </div>
          <span className="font-mono text-[10px] text-[#6B7280]">Resp API v1.4</span>
        </div>
      </div>
    </div>
  );
}
