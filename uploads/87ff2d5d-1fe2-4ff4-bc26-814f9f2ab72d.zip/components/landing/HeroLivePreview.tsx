'use client';

import React, { useState } from 'react';
import { MethodBadge } from '../ui/MethodBadge';
import { Check, Copy, Play, ArrowRight, CornerDownRight } from 'lucide-react';
import Link from 'next/link';

interface PreviewScenario {
  id: string;
  label: string;
  method: 'GET' | 'POST';
  path: string;
  statusCode: number;
  statusText: string;
  latency: string;
  size: string;
  headers: Record<string, string>;
  requestBody?: string;
  responseBody: string;
}

const SCENARIOS: PreviewScenario[] = [
  {
    id: 'users',
    label: 'GET Users',
    method: 'GET',
    path: '/api/v1/users',
    statusCode: 200,
    statusText: '200 OK',
    latency: '24ms',
    size: '1.2 KB',
    headers: {
      'content-type': 'application/json; charset=utf-8',
      'x-resp-version': '1.4.0',
      'ratelimit-remaining': '118'
    },
    responseBody: JSON.stringify(
      {
        success: true,
        meta: {
          page: 1,
          limit: 10,
          total: 24,
          totalPages: 3
        },
        data: [
          {
            id: 'usr_001',
            name: 'Alex Morgan',
            email: 'alex@example.com',
            role: 'lead_architect',
            status: 'active'
          },
          {
            id: 'usr_002',
            name: 'Sarah Chen',
            email: 'sarah.chen@devcorp.io',
            role: 'systems_engineer',
            status: 'active'
          }
        ]
      },
      null,
      2
    )
  },
  {
    id: 'auth',
    label: 'POST Auth Token',
    method: 'POST',
    path: '/api/v1/auth/tokens',
    statusCode: 200,
    statusText: '200 OK',
    latency: '18ms',
    size: '480 B',
    headers: {
      'content-type': 'application/json',
      'cache-control': 'no-store'
    },
    requestBody: JSON.stringify(
      {
        clientId: 'client_live_demo_987',
        clientSecret: 'sec_k89a12c4e7f800b21a',
        scopes: ['read:users', 'write:posts']
      },
      null,
      2
    ),
    responseBody: JSON.stringify(
      {
        success: true,
        data: {
          tokenType: 'Bearer',
          accessToken: 'rsp_tok_99fa71b8e0192ca5439a0',
          expiresIn: 3600,
          scopes: ['read:users', 'write:posts'],
          issuedAt: '2026-10-17T14:25:00Z'
        }
      },
      null,
      2
    )
  },
  {
    id: 'ping',
    label: 'GET Ping Latency',
    method: 'GET',
    path: '/api/v1/utilities/ping',
    statusCode: 200,
    statusText: '200 OK',
    latency: '9ms',
    size: '312 B',
    headers: {
      'content-type': 'application/json',
      'x-response-time': '9ms'
    },
    responseBody: JSON.stringify(
      {
        success: true,
        status: 'ok',
        pong: true,
        serverTime: '2026-10-17T14:26:00.120Z',
        region: 'sin1-sg',
        version: '1.4.0',
        uptimeSeconds: 842109
      },
      null,
      2
    )
  }
];

export function HeroLivePreview() {
  const [activeScenario, setActiveScenario] = useState<PreviewScenario>(SCENARIOS[0]);
  const [copied, setCopied] = useState(false);
  const [viewMode, setViewMode] = useState<'response' | 'headers'>('response');

  const handleCopy = () => {
    navigator.clipboard.writeText(activeScenario.responseBody);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="w-full rounded-lg border border-[#252A35] bg-[#10131A] shadow-xl overflow-hidden font-mono text-xs">
      {/* Top Bar: Selector Tabs */}
      <div className="flex flex-wrap items-center justify-between border-b border-[#252A35] bg-[#0D1016] px-3 py-2 gap-2">
        <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none">
          <span className="text-[10px] font-sans font-semibold text-[#6B7280] uppercase tracking-wider mr-1 select-none">
            Demo Request:
          </span>
          {SCENARIOS.map((sc) => (
            <button
              key={sc.id}
              onClick={() => setActiveScenario(sc)}
              className={`px-2.5 py-1 rounded text-xs transition-colors cursor-pointer ${
                activeScenario.id === sc.id
                  ? 'bg-[#151923] text-[#ECEFF4] border border-[#252A35] font-medium'
                  : 'text-[#9CA3AF] hover:text-[#ECEFF4] hover:bg-[#151923]/50'
              }`}
            >
              {sc.label}
            </button>
          ))}
        </div>

        <Link
          href={`/playground?endpoint=${encodeURIComponent(activeScenario.path)}&method=${activeScenario.method}`}
          className="inline-flex items-center gap-1 text-[11px] text-[#818CF8] hover:text-[#67E8F9] transition-colors"
        >
          <span>Open in Playground</span>
          <ArrowRight className="w-3 h-3" />
        </Link>
      </div>

      {/* URL & Method Display */}
      <div className="flex items-center justify-between border-b border-[#252A35] bg-[#151923] px-3.5 py-2.5">
        <div className="flex items-center gap-2 overflow-hidden">
          <MethodBadge method={activeScenario.method} size="sm" />
          <span className="text-[#ECEFF4] font-medium tracking-wide truncate">
            {activeScenario.path}
          </span>
        </div>

        <div className="flex items-center gap-2.5 shrink-0 text-[11px]">
          <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-[#4ADE80]/10 text-[#4ADE80] border border-[#4ADE80]/20 font-semibold">
            <span className="h-1.5 w-1.5 rounded-full bg-[#4ADE80]" />
            {activeScenario.statusText}
          </span>
          <span className="text-[#6B7280] hidden sm:inline">{activeScenario.latency}</span>
          <span className="text-[#6B7280] hidden sm:inline">{activeScenario.size}</span>
        </div>
      </div>

      {/* Response Sub-Header */}
      <div className="flex items-center justify-between border-b border-[#252A35]/60 bg-[#10131A] px-3.5 py-1.5 text-[11px] text-[#9CA3AF]">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setViewMode('response')}
            className={`cursor-pointer transition-colors ${
              viewMode === 'response' ? 'text-[#ECEFF4] font-medium' : 'text-[#6B7280] hover:text-[#9CA3AF]'
            }`}
          >
            Response Body (JSON)
          </button>
          <button
            onClick={() => setViewMode('headers')}
            className={`cursor-pointer transition-colors ${
              viewMode === 'headers' ? 'text-[#ECEFF4] font-medium' : 'text-[#6B7280] hover:text-[#9CA3AF]'
            }`}
          >
            Headers ({Object.keys(activeScenario.headers).length})
          </button>
        </div>

        <button
          onClick={handleCopy}
          className="inline-flex items-center gap-1 text-[11px] text-[#9CA3AF] hover:text-[#ECEFF4] cursor-pointer"
        >
          {copied ? (
            <>
              <Check className="w-3.5 h-3.5 text-[#4ADE80]" />
              <span className="text-[#4ADE80]">Copied</span>
            </>
          ) : (
            <>
              <Copy className="w-3.5 h-3.5" />
              <span>Copy Response</span>
            </>
          )}
        </button>
      </div>

      {/* Code Content Area */}
      <div className="p-4 bg-[#0B0D12] overflow-x-auto max-h-[290px] text-[13px] leading-relaxed text-[#ECEFF4]">
        {viewMode === 'response' ? (
          <pre className="m-0 font-mono">
            <code>{activeScenario.responseBody}</code>
          </pre>
        ) : (
          <div className="space-y-1.5 font-mono text-xs">
            {Object.entries(activeScenario.headers).map(([key, val]) => (
              <div key={key} className="flex gap-2">
                <span className="text-[#818CF8]">{key}:</span>
                <span className="text-[#9CA3AF]">{val}</span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Footer simulation hint */}
      <div className="flex items-center justify-between border-t border-[#252A35] bg-[#0D1016] px-3.5 py-1.5 text-[10px] text-[#6B7280]">
        <span>Demonstration telemetry — responses verified against contract spec</span>
        <span className="font-sans">Protocol: HTTP/2 TLS 1.3</span>
      </div>
    </div>
  );
}
