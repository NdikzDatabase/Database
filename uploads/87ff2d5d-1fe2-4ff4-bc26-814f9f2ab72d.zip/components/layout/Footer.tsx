'use client';

import React from 'react';
import Link from 'next/link';

export function Footer() {
  const currentYear = 2026;

  return (
    <footer className="border-t border-[#252A35] bg-[#0B0D12] text-xs text-[#9CA3AF]">
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          {/* Left: Brand + Status link */}
          <div className="flex flex-col sm:flex-row items-center gap-3">
            <div className="flex items-center gap-2">
              <div className="flex h-5 w-5 items-center justify-center rounded border border-[#818CF8]/40 bg-[#151923] text-[#818CF8]">
                <svg
                  width="12"
                  height="12"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2.5"
                >
                  <path d="M4 17l6-6-6-6" />
                  <path d="M12 19h8" />
                </svg>
              </div>
              <span className="font-semibold text-[#ECEFF4] tracking-wide text-xs">
                Resp<span className="text-[#818CF8]">API</span>
              </span>
            </div>

            <span className="hidden sm:inline text-[#252A35]">•</span>

            <Link
              href="/status"
              className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded border border-[#252A35] bg-[#10131A] text-[11px] text-[#9CA3AF] hover:text-[#ECEFF4] transition-colors"
            >
              <span className="relative flex h-1.5 w-1.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#4ADE80] opacity-75"></span>
                <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-[#4ADE80]"></span>
              </span>
              <span>All Systems Operational</span>
            </Link>
          </div>

          {/* Center / Right: Navigation Links */}
          <div className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-[11px]">
            <Link href="/explorer" className="hover:text-[#ECEFF4] transition-colors">
              API Explorer
            </Link>
            <Link href="/docs" className="hover:text-[#ECEFF4] transition-colors">
              Documentation
            </Link>
            <Link href="/playground" className="hover:text-[#ECEFF4] transition-colors">
              Playground
            </Link>
            <Link href="/changelog" className="hover:text-[#ECEFF4] transition-colors">
              Changelog
            </Link>
            <Link href="/status" className="hover:text-[#ECEFF4] transition-colors">
              Status
            </Link>
            <Link href="#" className="hover:text-[#ECEFF4] transition-colors">
              Privacy Policy
            </Link>
            <Link href="#" className="hover:text-[#ECEFF4] transition-colors">
              Terms of Service
            </Link>
          </div>

          {/* Right: Copyright */}
          <div className="text-[11px] text-[#6B7280]">
            © {currentYear} Resp API Platform. All rights reserved.
          </div>
        </div>
      </div>
    </footer>
  );
}
