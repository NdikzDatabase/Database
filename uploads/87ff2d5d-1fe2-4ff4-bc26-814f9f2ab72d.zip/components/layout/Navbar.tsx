'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  Layers,
  BookOpen,
  Terminal,
  History,
  Activity,
  Search,
  Menu,
  X,
  KeyRound,
  ExternalLink,
  ChevronRight,
  Check
} from 'lucide-react';

export function Navbar() {
  const pathname = usePathname();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [tokenModalOpen, setTokenModalOpen] = useState(false);
  const [copiedToken, setCopiedToken] = useState(false);

  const demoToken = 'rsp_live_99fa71b8e0192ca5439a0';

  const navLinks = [
    { name: 'Overview', href: '/' },
    { name: 'API Explorer', href: '/explorer', icon: Layers },
    { name: 'Documentation', href: '/docs', icon: BookOpen },
    { name: 'Playground', href: '/playground', icon: Terminal },
    { name: 'Changelog', href: '/changelog', icon: History },
    { name: 'Status', href: '/status', icon: Activity },
  ];

  const handleCopyToken = () => {
    navigator.clipboard.writeText(demoToken);
    setCopiedToken(true);
    setTimeout(() => setCopiedToken(false), 2000);
  };

  const triggerSearch = () => {
    window.dispatchEvent(new KeyboardEvent('keydown', { key: 'k', metaKey: true }));
  };

  return (
    <>
      <header className="sticky top-0 z-40 w-full border-b border-[#252A35] bg-[#0B0D12]">
        <div className="mx-auto flex h-14 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
          {/* Left: Brand Logo */}
          <div className="flex items-center gap-6">
            <Link
              href="/"
              className="flex items-center gap-2.5 text-[#ECEFF4] font-medium tracking-tight hover:opacity-90 transition-opacity"
            >
              {/* Minimalist Geometric Developer Logo */}
              <div className="flex h-7 w-7 items-center justify-center rounded border border-[#818CF8]/40 bg-[#151923] text-[#818CF8]">
                <svg
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2.2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M4 17l6-6-6-6" />
                  <path d="M12 19h8" />
                </svg>
              </div>
              <span className="text-sm font-semibold tracking-wide">
                Resp<span className="text-[#818CF8]">API</span>
              </span>
            </Link>

            {/* Desktop Navigation Links */}
            <nav className="hidden md:flex items-center space-x-1">
              {navLinks.map((link) => {
                const isActive = pathname === link.href || (link.href !== '/' && pathname.startsWith(link.href));
                return (
                  <Link
                    key={link.name}
                    href={link.href}
                    className={`px-3 py-1.5 text-xs font-medium rounded transition-colors ${
                      isActive
                        ? 'text-[#ECEFF4] bg-[#151923] border border-[#252A35]'
                        : 'text-[#9CA3AF] hover:text-[#ECEFF4] hover:bg-[#10131A]'
                    }`}
                  >
                    {link.name}
                  </Link>
                );
              })}
            </nav>
          </div>

          {/* Right: Search + Action Buttons */}
          <div className="flex items-center gap-2.5">
            {/* Search Trigger Button */}
            <button
              onClick={triggerSearch}
              className="flex items-center gap-2 h-8 px-2.5 rounded border border-[#252A35] bg-[#10131A] text-xs text-[#9CA3AF] hover:text-[#ECEFF4] hover:border-[#374151] transition-all cursor-pointer"
            >
              <Search className="w-3.5 h-3.5 text-[#6B7280]" />
              <span className="hidden lg:inline text-[11px]">Search docs & APIs...</span>
              <kbd className="hidden sm:inline-flex items-center gap-0.5 px-1 py-0.5 text-[9px] font-mono text-[#6B7280] bg-[#151923] border border-[#252A35] rounded">
                Ctrl K
              </kbd>
            </button>

            {/* Quick Demo Token Button */}
            <button
              onClick={() => setTokenModalOpen(true)}
              className="hidden sm:inline-flex items-center gap-1.5 h-8 px-2.5 rounded border border-[#252A35] bg-[#151923] text-xs font-medium text-[#ECEFF4] hover:bg-[#1f2432] transition-colors cursor-pointer"
            >
              <KeyRound className="w-3.5 h-3.5 text-[#818CF8]" />
              <span className="text-[11px]">Demo Key</span>
            </button>

            {/* GitHub / Repo link */}
            <Link
              href="https://github.com"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="GitHub Repository"
              className="inline-flex items-center justify-center h-8 w-8 rounded border border-[#252A35] bg-[#10131A] text-[#9CA3AF] hover:text-[#ECEFF4] hover:bg-[#151923] transition-colors"
            >
              <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor">
                <path fillRule="evenodd" clipRule="evenodd" d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.53 1.032 1.53 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0112 6.844c.85.004 1.705.115 2.504.337 1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.202 2.398.1 2.651.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.019 10.019 0 0022 12.017C22 6.484 17.522 2 12 2z" />
              </svg>
            </Link>

            {/* Mobile menu toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden inline-flex items-center justify-center h-8 w-8 rounded border border-[#252A35] bg-[#10131A] text-[#9CA3AF]"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-[#252A35] bg-[#10131A] px-4 py-3 space-y-1">
            {navLinks.map((link) => {
              const isActive = pathname === link.href || (link.href !== '/' && pathname.startsWith(link.href));
              const Icon = link.icon;
              return (
                <Link
                  key={link.name}
                  href={link.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className={`flex items-center justify-between px-3 py-2 rounded text-xs font-medium ${
                    isActive
                      ? 'text-[#ECEFF4] bg-[#151923] border border-[#252A35]'
                      : 'text-[#9CA3AF] hover:text-[#ECEFF4] hover:bg-[#151923]/50'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    {Icon && <Icon className="w-3.5 h-3.5 text-[#818CF8]" />}
                    <span>{link.name}</span>
                  </div>
                  <ChevronRight className="w-3.5 h-3.5 text-[#6B7280]" />
                </Link>
              );
            })}
            <div className="pt-2">
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  setTokenModalOpen(true);
                }}
                className="w-full flex items-center justify-center gap-2 py-2 text-xs font-medium rounded border border-[#252A35] bg-[#151923] text-[#ECEFF4]"
              >
                <KeyRound className="w-3.5 h-3.5 text-[#818CF8]" />
                <span>View Sandbox API Key</span>
              </button>
            </div>
          </div>
        )}
      </header>

      {/* Demo API Token Modal */}
      {tokenModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-[#0B0D12]/80 backdrop-blur-sm"
            onClick={() => setTokenModalOpen(false)}
          />
          <div className="relative w-full max-w-md rounded-lg border border-[#252A35] bg-[#10131A] p-5 shadow-2xl z-10">
            <div className="flex items-center justify-between pb-3 border-b border-[#252A35]">
              <div className="flex items-center gap-2">
                <KeyRound className="w-4 h-4 text-[#818CF8]" />
                <h3 className="text-sm font-semibold text-[#ECEFF4]">Sandbox API Token</h3>
              </div>
              <button
                onClick={() => setTokenModalOpen(false)}
                className="text-[#6B7280] hover:text-[#ECEFF4]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="mt-3 text-xs text-[#9CA3AF] leading-relaxed">
              Use this pre-configured developer token to authenticate requests in the Playground or directly via curl.
            </p>

            <div className="mt-3 flex items-center justify-between rounded border border-[#252A35] bg-[#0D1016] px-3 py-2 font-mono text-xs text-[#ECEFF4]">
              <span className="truncate">{demoToken}</span>
              <button
                onClick={handleCopyToken}
                className="ml-2 shrink-0 inline-flex items-center gap-1 text-[11px] text-[#818CF8] hover:text-[#67E8F9] cursor-pointer"
              >
                {copiedToken ? (
                  <>
                    <Check className="w-3 h-3 text-[#4ADE80]" />
                    <span className="text-[#4ADE80]">Copied</span>
                  </>
                ) : (
                  <span>Copy</span>
                )}
              </button>
            </div>

            <div className="mt-4 flex items-center justify-between text-[11px] text-[#6B7280]">
              <span>Rate Limit: 120 req/min</span>
              <span>Expires: In 24 hours</span>
            </div>

            <div className="mt-5 flex justify-end">
              <button
                onClick={() => setTokenModalOpen(false)}
                className="px-3.5 py-1.5 text-xs font-medium rounded border border-[#252A35] bg-[#151923] text-[#ECEFF4] hover:bg-[#1f2432]"
              >
                Dismiss
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
