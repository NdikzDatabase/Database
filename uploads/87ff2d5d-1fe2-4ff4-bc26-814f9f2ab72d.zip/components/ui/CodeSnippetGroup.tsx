'use client';

import React, { useState } from 'react';
import { Check, Copy, Terminal } from 'lucide-react';

export interface CodeSnippet {
  language: string;
  label: string;
  code: string;
}

interface CodeSnippetGroupProps {
  snippets: CodeSnippet[];
  title?: string;
  className?: string;
}

export function CodeSnippetGroup({ snippets, title, className = '' }: CodeSnippetGroupProps) {
  const [activeTab, setActiveTab] = useState(0);
  const [copied, setCopied] = useState(false);

  const activeSnippet = snippets[activeTab] || snippets[0];

  const handleCopy = async () => {
    if (!activeSnippet) return;
    try {
      await navigator.clipboard.writeText(activeSnippet.code);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Fallback
    }
  };

  return (
    <div className={`rounded-md border border-[#252A35] bg-[#0D1016] overflow-hidden text-sm font-mono ${className}`}>
      <div className="flex items-center justify-between border-b border-[#252A35] bg-[#10131A] px-2 py-1.5">
        <div className="flex items-center gap-1 overflow-x-auto scrollbar-none">
          {title && (
            <div className="flex items-center gap-1.5 px-2 py-1 text-xs text-[#9CA3AF] border-r border-[#252A35] mr-1">
              <Terminal className="w-3.5 h-3.5 text-[#818CF8]" />
              <span className="font-sans font-medium text-[#ECEFF4]">{title}</span>
            </div>
          )}
          {snippets.map((snip, index) => {
            const isActive = index === activeTab;
            return (
              <button
                key={snip.language}
                onClick={() => setActiveTab(index)}
                className={`px-2.5 py-1 text-xs font-mono rounded transition-colors cursor-pointer ${
                  isActive
                    ? 'bg-[#151923] text-[#ECEFF4] border border-[#252A35]'
                    : 'text-[#6B7280] hover:text-[#9CA3AF]'
                }`}
              >
                {snip.label}
              </button>
            );
          })}
        </div>

        <button
          onClick={handleCopy}
          aria-label="Copy snippet"
          className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded text-[11px] text-[#9CA3AF] hover:text-[#ECEFF4] hover:bg-[#151923] border border-transparent hover:border-[#252A35] transition-all cursor-pointer ml-2 shrink-0"
        >
          {copied ? (
            <>
              <Check className="w-3.5 h-3.5 text-[#4ADE80]" />
              <span className="text-[#4ADE80]">Copied</span>
            </>
          ) : (
            <>
              <Copy className="w-3.5 h-3.5" />
              <span>Copy</span>
            </>
          )}
        </button>
      </div>

      <div className="p-4 overflow-x-auto text-[13px] leading-relaxed text-[#ECEFF4] bg-[#0B0D12]">
        <pre className="whitespace-pre font-mono m-0">
          <code>{activeSnippet?.code}</code>
        </pre>
      </div>
    </div>
  );
}
