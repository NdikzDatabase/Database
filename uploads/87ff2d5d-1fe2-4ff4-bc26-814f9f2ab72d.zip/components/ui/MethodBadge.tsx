import React from 'react';
import { HttpMethod } from '@/data/endpoints';

interface MethodBadgeProps {
  method: HttpMethod | string;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

export function MethodBadge({ method, size = 'sm', className = '' }: MethodBadgeProps) {
  const upper = method.toUpperCase();

  const sizeClasses = {
    sm: 'text-[10px] px-1.5 py-0.5 tracking-wider font-semibold',
    md: 'text-xs px-2 py-0.5 tracking-wide font-medium',
    lg: 'text-sm px-2.5 py-1 tracking-wide font-medium'
  }[size];

  const colorClasses = {
    GET: 'bg-[#4ADE80]/10 text-[#4ADE80] border-[#4ADE80]/30',
    POST: 'bg-[#818CF8]/10 text-[#818CF8] border-[#818CF8]/30',
    PUT: 'bg-[#FBBF24]/10 text-[#FBBF24] border-[#FBBF24]/30',
    PATCH: 'bg-[#FBBF24]/10 text-[#FBBF24] border-[#FBBF24]/30',
    DELETE: 'bg-[#F87171]/10 text-[#F87171] border-[#F87171]/30',
  }[upper] || 'bg-gray-800 text-gray-300 border-gray-700';

  return (
    <span
      className={`inline-flex items-center justify-center font-mono rounded border uppercase select-none transition-colors ${sizeClasses} ${colorClasses} ${className}`}
    >
      {upper}
    </span>
  );
}
