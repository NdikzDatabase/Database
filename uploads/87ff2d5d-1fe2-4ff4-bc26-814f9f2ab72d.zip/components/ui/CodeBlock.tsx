'use client';

import React, { useState } from 'react';
import { Check, Copy } from 'lucide-react';

interface CodeBlockProps {
  code: string;
  language?: string;
  title?: string;
  showLineNumbers?: boolean;
  className?: string;
  copyable?: boolean;
}

export function CodeBlock({
  code,
  language = 'bash',
  title,
  showLineNumbers = false,
  className = '',
  copyable = true,
}: CodeBlockProps) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Fallback
    }
  };

  const lines = code.trim().split('\n');

  return (
    <div
      className={`rounded-md border border-[#252A35] bg-[#0D1016] overflow-hidden text-sm font-mono shadow-sm ${className}`}
    >
      {(title || language || copyable) && (
        <div className="flex items-center justify-between px-3.5 py-2 border-b border-[#252A35] bg-[#10131A] text-xs">
          <div className="flex items-center space-x-2 text-[#9CA3AF]">
            {title ? (
              <span className="text-[#ECEFF4] font-medium tracking-wide">{title}</span>
            ) : (
              <span className="uppercase tracking-wider text-[11px] text-[#6B7280] font-semibold">{language}</span>
            )}
          </div>
          {copyable && (
            <button
              onClick={handleCopy}
              aria-label="Copy code snippet"
              className="inline-flex items-center gap-1.5 px-2 py-1 rounded text-[11px] text-[#9CA3AF] hover:text-[#ECEFF4] hover:bg-[#151923] border border-transparent hover:border-[#252A35] transition-all cursor-pointer"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-[#4ADE80]" />
                  <span className="text-[#4ADE80]">Copied</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy</span>
                </>
              )}
            </button>
          )}
        </div>
      )}

      <div className="p-3.5 overflow-x-auto text-[13px] leading-relaxed text-[#ECEFF4]">
        {showLineNumbers ? (
          <table className="w-full border-collapse">
            <tbody>
              {lines.map((line, idx) => (
                <tr key={idx} className="hover:bg-[#151923]/40">
                  <td className="pr-4 select-none text-right text-[12px] text-[#6B7280] w-8 align-top">
                    {idx + 1}
                  </td>
                  <td className="whitespace-pre font-mono">{line}</td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <pre className="whitespace-pre font-mono m-0">
            <code>{code}</code>
          </pre>
        )}
      </div>
    </div>
  );
}
