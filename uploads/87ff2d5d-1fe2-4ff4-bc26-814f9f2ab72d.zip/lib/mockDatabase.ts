// In-memory mock database for live API execution

export interface UserRecord {
  id: string;
  name: string;
  email: string;
  role: string;
  tier: string;
  status: 'active' | 'pending' | 'suspended';
  createdAt: string;
}

export interface PostRecord {
  id: string;
  title: string;
  slug: string;
  content: string;
  author: string;
  tag: string;
  views: number;
  publishedAt: string;
}

export interface ProductRecord {
  id: string;
  sku: string;
  name: string;
  category: string;
  price: number;
  currency: string;
  stock: number;
  inStock: boolean;
  description: string;
}

export const initialUsers: UserRecord[] = [
  {
    id: 'usr_001',
    name: 'Alex Morgan',
    email: 'alex@example.com',
    role: 'lead_architect',
    tier: 'enterprise',
    status: 'active',
    createdAt: '2026-03-12T08:14:20Z'
  },
  {
    id: 'usr_002',
    name: 'Sarah Chen',
    email: 'sarah.chen@devcorp.io',
    role: 'systems_engineer',
    tier: 'pro',
    status: 'active',
    createdAt: '2026-04-01T12:00:15Z'
  },
  {
    id: 'usr_003',
    name: 'Dmitri Volkov',
    email: 'dmitri@binarystack.net',
    role: 'developer',
    tier: 'standard',
    status: 'pending',
    createdAt: '2026-05-18T19:42:01Z'
  },
  {
    id: 'usr_004',
    name: 'Elena Rostova',
    email: 'elena@deepkernel.dev',
    role: 'developer',
    tier: 'pro',
    status: 'active',
    createdAt: '2026-06-22T11:10:05Z'
  }
];

export const initialPosts: PostRecord[] = [
  {
    id: 'pst_101',
    title: 'Building Predictable REST Contracts with Zero Drift',
    slug: 'building-predictable-rest-contracts',
    content: 'REST APIs remain the bedrock of distributed system design. Strict type schemas and version guarantees ensure zero drift between client and server expectations.',
    author: 'Alex Morgan',
    tag: 'engineering',
    views: 4210,
    publishedAt: '2026-09-28T10:00:00Z'
  },
  {
    id: 'pst_102',
    title: 'Migrating Edge CDN Gateways with Sub-5ms TLS Handshakes',
    slug: 'migrating-edge-cdn-gateways',
    content: 'By terminating TLS at 240 edge points-of-presence globally, connection handshake latency was reduced from 65ms to 4.2ms.',
    author: 'Sarah Chen',
    tag: 'infrastructure',
    views: 2890,
    publishedAt: '2026-10-04T16:30:00Z'
  }
];

export const initialProducts: ProductRecord[] = [
  {
    id: 'prd_901',
    sku: 'HW-MOD-GATE-01',
    name: 'Edge Gateway Appliance V2',
    category: 'hardware',
    price: 499.00,
    currency: 'USD',
    stock: 42,
    inStock: true,
    description: 'Low-latency rackmount hardware gateway with dual 10GbE SFP+ uplinks.'
  },
  {
    id: 'prd_902',
    sku: 'SW-LIC-CLUSTER-ENT',
    name: 'Enterprise Cluster License (1 Year)',
    category: 'software',
    price: 2400.00,
    currency: 'USD',
    stock: 9999,
    inStock: true,
    description: 'Production cluster orchestrator license with 24/7 dedicated SLA.'
  }
];
