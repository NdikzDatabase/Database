'use client';

import React, { useState, useEffect, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import {
  Play,
  Copy,
  Check,
  RotateCcw,
  Plus,
  Trash2,
  Terminal,
  Clock,
  HardDrive,
  Code2,
  Sliders,
  KeyRound,
  FileText,
  History,
  AlertTriangle,
  ArrowRight,
  ExternalLink,
  ChevronDown
} from 'lucide-react';
import { MethodBadge } from '@/components/ui/MethodBadge';
import { HttpMethod } from '@/data/endpoints';

interface KeyValuePair {
  id: string;
  key: string;
  value: string;
  enabled: boolean;
}

interface RequestHistoryItem {
  id: string;
  method: HttpMethod;
  url: string;
  status: number;
  timeMs: number;
  timestamp: string;
}

const PRESET_ENDPOINTS = [
  { method: 'GET' as HttpMethod, path: '/api/v1/users', label: 'List Users' },
  { method: 'GET' as HttpMethod, path: '/api/v1/users/usr_001', label: 'Get User (usr_001)' },
  { method: 'POST' as HttpMethod, path: '/api/v1/users', label: 'Create User' },
  { method: 'GET' as HttpMethod, path: '/api/v1/posts', label: 'List Posts' },
  { method: 'GET' as HttpMethod, path: '/api/v1/products', label: 'List Products' },
  { method: 'POST' as HttpMethod, path: '/api/v1/auth/tokens', label: 'Issue Auth Token' },
  { method: 'GET' as HttpMethod, path: '/api/v1/auth/verify', label: 'Verify Token Claims' },
  { method: 'GET' as HttpMethod, path: '/api/v1/utilities/ping', label: 'Diagnostic Ping' },
  { method: 'POST' as HttpMethod, path: '/api/v1/utilities/echo', label: 'Echo Request Inspector' },
  { method: 'GET' as HttpMethod, path: '/api/v1/utilities/rate-limit', label: 'Rate Limit Inspection' },
];

function PlaygroundContent() {
  const searchParams = useSearchParams();
  const initialEndpoint = searchParams.get('endpoint') || '/api/v1/users';
  const initialMethod = (searchParams.get('method')?.toUpperCase() as HttpMethod) || 'GET';

  // Request state
  const [method, setMethod] = useState<HttpMethod>(initialMethod);
  const [url, setUrl] = useState<string>(initialEndpoint);
  const [activeTab, setActiveTab] = useState<'params' | 'headers' | 'body' | 'auth'>('params');

  // Params
  const [params, setParams] = useState<KeyValuePair[]>([
    { id: '1', key: 'page', value: '1', enabled: true },
    { id: '2', key: 'limit', value: '10', enabled: true }
  ]);

  // Headers
  const [headers, setHeaders] = useState<KeyValuePair[]>([
    { id: '1', key: 'Accept', value: 'application/json', enabled: true },
    { id: '2', key: 'X-Requested-With', value: 'RespAPI-Playground', enabled: true }
  ]);

  // Auth
  const [authType, setAuthType] = useState<'none' | 'bearer' | 'apikey'>('none');
  const [bearerToken, setBearerToken] = useState('rsp_live_99fa71b8e0192ca5439a0');
  const [apiKey, setApiKey] = useState('rsp_ak_sec8910b2');

  // Body
  const [bodyContent, setBodyContent] = useState<string>(
    JSON.stringify(
      {
        name: 'Elena Rostova',
        email: 'elena@deepkernel.dev',
        role: 'developer'
      },
      null,
      2
    )
  );

  // Response state
  const [loading, setLoading] = useState(false);
  const [responseStatus, setResponseStatus] = useState<number | null>(null);
  const [responseStatusText, setResponseStatusText] = useState<string>('');
  const [responseHeaders, setResponseHeaders] = useState<Record<string, string>>({});
  const [responseData, setResponseData] = useState<string | null>(null);
  const [responseTime, setResponseTime] = useState<number | null>(null);
  const [responseSize, setResponseSize] = useState<string | null>(null);
  const [responseView, setResponseView] = useState<'body' | 'headers'>('body');
  const [copiedResponse, setCopiedResponse] = useState(false);

  // History state
  const [history, setHistory] = useState<RequestHistoryItem[]>([]);
  const [historyOpen, setHistoryOpen] = useState(false);

  // Watch for incoming query params
  useEffect(() => {
    if (searchParams.get('endpoint')) {
      setUrl(searchParams.get('endpoint') || '/api/v1/users');
    }
    if (searchParams.get('method')) {
      setMethod((searchParams.get('method')?.toUpperCase() as HttpMethod) || 'GET');
    }
  }, [searchParams]);

  // Key-Value table helpers
  const addParam = () => {
    setParams([...params, { id: Math.random().toString(), key: '', value: '', enabled: true }]);
  };

  const removeParam = (id: string) => {
    setParams(params.filter((p) => p.id !== id));
  };

  const updateParam = (id: string, field: 'key' | 'value' | 'enabled', val: string | boolean) => {
    setParams(
      params.map((p) => (p.id === id ? { ...p, [field]: val } : p))
    );
  };

  const addHeader = () => {
    setHeaders([...headers, { id: Math.random().toString(), key: '', value: '', enabled: true }]);
  };

  const removeHeader = (id: string) => {
    setHeaders(headers.filter((h) => h.id !== id));
  };

  const updateHeader = (id: string, field: 'key' | 'value' | 'enabled', val: string | boolean) => {
    setHeaders(
      headers.map((h) => (h.id === id ? { ...h, [field]: val } : h))
    );
  };

  // Prettify JSON Body
  const formatJsonBody = () => {
    try {
      const parsed = JSON.parse(bodyContent);
      setBodyContent(JSON.stringify(parsed, null, 2));
    } catch {
      // Invalid JSON
    }
  };

  // Copy response
  const handleCopyResponse = () => {
    if (!responseData) return;
    navigator.clipboard.writeText(responseData);
    setCopiedResponse(true);
    setTimeout(() => setCopiedResponse(false), 2000);
  };

  // Execute Request (Calls local API route)
  const handleSendRequest = async () => {
    setLoading(true);
    setResponseStatus(null);
    setResponseData(null);

    // Build URL with query params
    const activeParams = params.filter((p) => p.enabled && p.key.trim());
    let targetUrl = url.trim();

    if (activeParams.length > 0) {
      const queryString = activeParams
        .map((p) => `${encodeURIComponent(p.key.trim())}=${encodeURIComponent(p.value.trim())}`)
        .join('&');
      targetUrl += targetUrl.includes('?') ? `&${queryString}` : `?${queryString}`;
    }

    // Build headers object
    const reqHeaders: Record<string, string> = {};
    headers
      .filter((h) => h.enabled && h.key.trim())
      .forEach((h) => {
        reqHeaders[h.key.trim()] = h.value.trim();
      });

    // Inject auth header
    if (authType === 'bearer' && bearerToken) {
      reqHeaders['Authorization'] = `Bearer ${bearerToken.trim()}`;
    } else if (authType === 'apikey' && apiKey) {
      reqHeaders['X-API-Key'] = apiKey.trim();
    }

    if (method !== 'GET' && method !== 'DELETE' && !reqHeaders['Content-Type']) {
      reqHeaders['Content-Type'] = 'application/json';
    }

    const startTime = performance.now();

    try {
      const fetchOptions: RequestInit = {
        method,
        headers: reqHeaders,
      };

      if (method !== 'GET' && bodyContent.trim()) {
        fetchOptions.body = bodyContent;
      }

      const res = await fetch(targetUrl, fetchOptions);
      const elapsed = Math.round(performance.now() - startTime);

      setResponseStatus(res.status);
      setResponseStatusText(res.statusText || `${res.status}`);
      setResponseTime(elapsed);

      // Extract headers
      const resHeadersObj: Record<string, string> = {};
      res.headers.forEach((val, key) => {
        resHeadersObj[key] = val;
      });
      setResponseHeaders(resHeadersObj);

      // Parse body
      const text = await res.text();
      setResponseSize(`${(new Blob([text]).size / 1024).toFixed(2)} KB`);

      try {
        const json = JSON.parse(text);
        setResponseData(JSON.stringify(json, null, 2));
      } catch {
        setResponseData(text);
      }

      // Add to history
      const newHistoryItem: RequestHistoryItem = {
        id: Math.random().toString(),
        method,
        url: targetUrl,
        status: res.status,
        timeMs: elapsed,
        timestamp: new Date().toLocaleTimeString(),
      };
      setHistory((prev) => [newHistoryItem, ...prev.slice(0, 19)]);
    } catch (err: unknown) {
      const elapsed = Math.round(performance.now() - startTime);
      setResponseStatus(500);
      setResponseStatusText('Client Network Error');
      setResponseTime(elapsed);
      setResponseSize('0 B');
      setResponseData(
        JSON.stringify(
          {
            error: 'CLIENT_REQUEST_FAILED',
            message: err instanceof Error ? err.message : 'Unknown network failure',
            tip: 'Check that the URL path exists and corresponds to a supported API route.'
          },
          null,
          2
        )
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0B0D12]">
      {/* Top Bar */}
      <div className="border-b border-[#252A35] bg-[#10131A] py-4">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="flex h-7 w-7 items-center justify-center rounded border border-[#4ADE80]/40 bg-[#151923] text-[#4ADE80]">
              <Terminal className="w-4 h-4" />
            </div>
            <div>
              <h1 className="text-base font-semibold text-[#ECEFF4] tracking-tight">
                API Playground
              </h1>
              <p className="text-[11px] text-[#9CA3AF]">
                Execute live HTTP requests against local sandbox routes with real status codes & headers
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setHistoryOpen(!historyOpen)}
              className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded border border-[#252A35] bg-[#151923] text-xs text-[#9CA3AF] hover:text-[#ECEFF4] cursor-pointer"
            >
              <History className="w-3.5 h-3.5 text-[#818CF8]" />
              <span>History ({history.length})</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Split Layout Container */}
      <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
        {/* Preset Selector Dropdown */}
        <div className="mb-4 flex flex-wrap items-center gap-2">
          <span className="text-[11px] font-mono text-[#6B7280] uppercase tracking-wider">
            Quick Preset:
          </span>
          <div className="flex flex-wrap items-center gap-1.5 overflow-x-auto">
            {PRESET_ENDPOINTS.map((preset) => (
              <button
                key={preset.path + preset.method}
                onClick={() => {
                  setMethod(preset.method);
                  setUrl(preset.path);
                  if (preset.path.includes('auth/tokens')) {
                    setActiveTab('body');
                    setBodyContent(
                      JSON.stringify(
                        {
                          clientId: 'client_live_demo_987',
                          clientSecret: 'sec_k89a12c4e7f800b21a',
                          scopes: ['read:users', 'write:posts']
                        },
                        null,
                        2
                      )
                    );
                  } else if (preset.path.includes('auth/verify')) {
                    setAuthType('bearer');
                    setActiveTab('auth');
                  }
                }}
                className={`px-2 py-0.5 rounded text-[11px] font-mono border transition-colors cursor-pointer ${
                  url === preset.path && method === preset.method
                    ? 'bg-[#151923] text-[#ECEFF4] border-[#818CF8]'
                    : 'bg-[#10131A] text-[#9CA3AF] border-[#252A35] hover:text-[#ECEFF4]'
                }`}
              >
                <span className="text-[#818CF8] mr-1">{preset.method}</span>
                <span>{preset.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* URL Input Bar & Action Row */}
        <div className="rounded-lg border border-[#252A35] bg-[#10131A] p-2 mb-6 flex flex-col sm:flex-row items-center gap-2 shadow-md">
          {/* Method Selector */}
          <select
            value={method}
            onChange={(e) => setMethod(e.target.value as HttpMethod)}
            aria-label="HTTP Method"
            className="w-full sm:w-28 rounded border border-[#252A35] bg-[#0D1016] px-2.5 py-2 font-mono text-xs font-semibold text-[#818CF8] outline-none cursor-pointer"
          >
            <option value="GET">GET</option>
            <option value="POST">POST</option>
            <option value="PUT">PUT</option>
            <option value="PATCH">PATCH</option>
            <option value="DELETE">DELETE</option>
          </select>

          {/* URL Input */}
          <input
            type="text"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            aria-label="Endpoint URL Path"
            placeholder="/api/v1/users"
            className="w-full flex-1 rounded border border-[#252A35] bg-[#0D1016] px-3 py-2 font-mono text-xs text-[#ECEFF4] placeholder-[#6B7280] outline-none focus:border-[#818CF8]/60"
          />

          {/* Send Request Button */}
          <button
            onClick={handleSendRequest}
            disabled={loading}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 h-9 px-5 rounded bg-[#818CF8] hover:bg-[#6366F1] disabled:opacity-50 text-xs font-semibold text-[#0B0D12] transition-colors cursor-pointer shrink-0"
          >
            {loading ? (
              <>
                <span className="h-3 w-3 animate-spin rounded-full border-2 border-[#0B0D12] border-t-transparent" />
                <span>Sending...</span>
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>Send Request</span>
              </>
            )}
          </button>
        </div>

        {/* Workbench Area: Split on desktop (Left: Request Config, Right: Response Panel) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Left Column: Request Configuration */}
          <div className="lg:col-span-6 rounded-lg border border-[#252A35] bg-[#10131A] overflow-hidden flex flex-col min-h-[460px]">
            {/* Config Tabs */}
            <div className="flex items-center border-b border-[#252A35] bg-[#0D1016] px-3 pt-2 gap-1 text-xs font-medium">
              <button
                onClick={() => setActiveTab('params')}
                className={`px-3 py-2 border-b-2 transition-colors cursor-pointer ${
                  activeTab === 'params'
                    ? 'border-[#818CF8] text-[#ECEFF4]'
                    : 'border-transparent text-[#6B7280] hover:text-[#9CA3AF]'
                }`}
              >
                Params ({params.filter((p) => p.enabled && p.key.trim()).length})
              </button>
              <button
                onClick={() => setActiveTab('headers')}
                className={`px-3 py-2 border-b-2 transition-colors cursor-pointer ${
                  activeTab === 'headers'
                    ? 'border-[#818CF8] text-[#ECEFF4]'
                    : 'border-transparent text-[#6B7280] hover:text-[#9CA3AF]'
                }`}
              >
                Headers ({headers.filter((h) => h.enabled && h.key.trim()).length})
              </button>
              <button
                onClick={() => setActiveTab('body')}
                className={`px-3 py-2 border-b-2 transition-colors cursor-pointer ${
                  activeTab === 'body'
                    ? 'border-[#818CF8] text-[#ECEFF4]'
                    : 'border-transparent text-[#6B7280] hover:text-[#9CA3AF]'
                }`}
              >
                Body {method === 'GET' ? '(Disabled)' : ''}
              </button>
              <button
                onClick={() => setActiveTab('auth')}
                className={`px-3 py-2 border-b-2 transition-colors cursor-pointer ${
                  activeTab === 'auth'
                    ? 'border-[#818CF8] text-[#ECEFF4]'
                    : 'border-transparent text-[#6B7280] hover:text-[#9CA3AF]'
                }`}
              >
                Auth ({authType})
              </button>
            </div>

            {/* Tab Contents */}
            <div className="p-4 flex-1">
              {/* TAB 1: PARAMS */}
              {activeTab === 'params' && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-xs text-[#9CA3AF]">
                    <span>Query Parameters</span>
                    <button
                      onClick={addParam}
                      className="inline-flex items-center gap-1 text-[#818CF8] hover:text-[#67E8F9] cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Add Parameter</span>
                    </button>
                  </div>

                  <div className="space-y-2">
                    {params.map((param) => (
                      <div key={param.id} className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={param.enabled}
                          onChange={(e) => updateParam(param.id, 'enabled', e.target.checked)}
                          className="rounded border-[#252A35] text-[#818CF8] bg-[#0D1016]"
                        />
                        <input
                          type="text"
                          value={param.key}
                          onChange={(e) => updateParam(param.id, 'key', e.target.value)}
                          placeholder="Key"
                          className="w-1/2 rounded border border-[#252A35] bg-[#0D1016] px-2.5 py-1.5 font-mono text-xs text-[#ECEFF4] placeholder-[#6B7280] outline-none"
                        />
                        <input
                          type="text"
                          value={param.value}
                          onChange={(e) => updateParam(param.id, 'value', e.target.value)}
                          placeholder="Value"
                          className="w-1/2 rounded border border-[#252A35] bg-[#0D1016] px-2.5 py-1.5 font-mono text-xs text-[#ECEFF4] placeholder-[#6B7280] outline-none"
                        />
                        <button
                          onClick={() => removeParam(param.id)}
                          className="text-[#6B7280] hover:text-[#F87171] p-1 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 2: HEADERS */}
              {activeTab === 'headers' && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-xs text-[#9CA3AF]">
                    <span>Request Headers</span>
                    <button
                      onClick={addHeader}
                      className="inline-flex items-center gap-1 text-[#818CF8] hover:text-[#67E8F9] cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Add Header</span>
                    </button>
                  </div>

                  <div className="space-y-2">
                    {headers.map((hdr) => (
                      <div key={hdr.id} className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={hdr.enabled}
                          onChange={(e) => updateHeader(hdr.id, 'enabled', e.target.checked)}
                          className="rounded border-[#252A35] text-[#818CF8] bg-[#0D1016]"
                        />
                        <input
                          type="text"
                          value={hdr.key}
                          onChange={(e) => updateHeader(hdr.id, 'key', e.target.value)}
                          placeholder="Header Name"
                          className="w-1/2 rounded border border-[#252A35] bg-[#0D1016] px-2.5 py-1.5 font-mono text-xs text-[#ECEFF4] placeholder-[#6B7280] outline-none"
                        />
                        <input
                          type="text"
                          value={hdr.value}
                          onChange={(e) => updateHeader(hdr.id, 'value', e.target.value)}
                          placeholder="Header Value"
                          className="w-1/2 rounded border border-[#252A35] bg-[#0D1016] px-2.5 py-1.5 font-mono text-xs text-[#ECEFF4] placeholder-[#6B7280] outline-none"
                        />
                        <button
                          onClick={() => removeHeader(hdr.id)}
                          className="text-[#6B7280] hover:text-[#F87171] p-1 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 3: BODY */}
              {activeTab === 'body' && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-xs text-[#9CA3AF]">
                    <span>JSON Request Body</span>
                    <button
                      onClick={formatJsonBody}
                      className="text-[11px] text-[#818CF8] hover:text-[#67E8F9] cursor-pointer"
                    >
                      Format JSON
                    </button>
                  </div>

                  <textarea
                    rows={12}
                    value={bodyContent}
                    onChange={(e) => setBodyContent(e.target.value)}
                    placeholder='{"key": "value"}'
                    className="w-full rounded border border-[#252A35] bg-[#0D1016] p-3 font-mono text-xs text-[#ECEFF4] placeholder-[#6B7280] outline-none focus:border-[#818CF8]/60 resize-none"
                  />
                </div>
              )}

              {/* TAB 4: AUTH */}
              {activeTab === 'auth' && (
                <div className="space-y-4 text-xs">
                  <div>
                    <label className="block text-[#9CA3AF] mb-1.5 font-medium">
                      Authorization Type
                    </label>
                    <select
                      value={authType}
                      onChange={(e) => setAuthType(e.target.value as 'none' | 'bearer' | 'apikey')}
                      className="rounded border border-[#252A35] bg-[#0D1016] px-3 py-1.5 text-xs text-[#ECEFF4] outline-none"
                    >
                      <option value="none">No Auth</option>
                      <option value="bearer">Bearer Token</option>
                      <option value="apikey">API Key (X-API-Key)</option>
                    </select>
                  </div>

                  {authType === 'bearer' && (
                    <div className="space-y-2">
                      <label className="block text-[#9CA3AF]">Token Value</label>
                      <input
                        type="text"
                        value={bearerToken}
                        onChange={(e) => setBearerToken(e.target.value)}
                        className="w-full rounded border border-[#252A35] bg-[#0D1016] px-3 py-2 font-mono text-xs text-[#ECEFF4] outline-none focus:border-[#818CF8]/60"
                      />
                      <p className="text-[11px] text-[#6B7280]">
                        Will be automatically added as <code className="text-[#818CF8]">Authorization: Bearer &lt;TOKEN&gt;</code>
                      </p>
                    </div>
                  )}

                  {authType === 'apikey' && (
                    <div className="space-y-2">
                      <label className="block text-[#9CA3AF]">API Key Value</label>
                      <input
                        type="text"
                        value={apiKey}
                        onChange={(e) => setApiKey(e.target.value)}
                        className="w-full rounded border border-[#252A35] bg-[#0D1016] px-3 py-2 font-mono text-xs text-[#ECEFF4] outline-none focus:border-[#818CF8]/60"
                      />
                      <p className="text-[11px] text-[#6B7280]">
                        Will be injected into the <code className="text-[#818CF8]">X-API-Key</code> request header.
                      </p>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Right Column: Response Viewer Panel */}
          <div className="lg:col-span-6 rounded-lg border border-[#252A35] bg-[#10131A] overflow-hidden flex flex-col min-h-[460px]">
            {/* Response Header Status Bar */}
            <div className="flex items-center justify-between border-b border-[#252A35] bg-[#0D1016] px-3.5 py-2.5">
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold text-[#ECEFF4]">Response</span>
                {responseStatus !== null && (
                  <span
                    className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-mono font-semibold ${
                      responseStatus >= 200 && responseStatus < 300
                        ? 'bg-[#4ADE80]/10 text-[#4ADE80] border border-[#4ADE80]/30'
                        : responseStatus >= 400 && responseStatus < 500
                        ? 'bg-[#FBBF24]/10 text-[#FBBF24] border border-[#FBBF24]/30'
                        : 'bg-[#F87171]/10 text-[#F87171] border border-[#F87171]/30'
                    }`}
                  >
                    {responseStatus} {responseStatusText}
                  </span>
                )}
              </div>

              {responseStatus !== null && (
                <div className="flex items-center gap-3 text-[11px] font-mono text-[#6B7280]">
                  {responseTime !== null && (
                    <span className="inline-flex items-center gap-1">
                      <Clock className="w-3 h-3 text-[#818CF8]" />
                      <span>{responseTime}ms</span>
                    </span>
                  )}
                  {responseSize !== null && (
                    <span className="inline-flex items-center gap-1">
                      <HardDrive className="w-3 h-3 text-[#67E8F9]" />
                      <span>{responseSize}</span>
                    </span>
                  )}
                </div>
              )}
            </div>

            {/* Response Sub Tabs & Action buttons */}
            {responseStatus !== null && (
              <div className="flex items-center justify-between border-b border-[#252A35]/60 bg-[#10131A] px-3.5 py-1.5 text-xs">
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => setResponseView('body')}
                    className={`cursor-pointer transition-colors ${
                      responseView === 'body'
                        ? 'text-[#ECEFF4] font-medium'
                        : 'text-[#6B7280] hover:text-[#9CA3AF]'
                    }`}
                  >
                    JSON Body
                  </button>
                  <button
                    onClick={() => setResponseView('headers')}
                    className={`cursor-pointer transition-colors ${
                      responseView === 'headers'
                        ? 'text-[#ECEFF4] font-medium'
                        : 'text-[#6B7280] hover:text-[#9CA3AF]'
                    }`}
                  >
                    Headers ({Object.keys(responseHeaders).length})
                  </button>
                </div>

                <button
                  onClick={handleCopyResponse}
                  className="inline-flex items-center gap-1 text-[11px] text-[#9CA3AF] hover:text-[#ECEFF4] cursor-pointer"
                >
                  {copiedResponse ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-[#4ADE80]" />
                      <span className="text-[#4ADE80]">Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy</span>
                    </>
                  )}
                </button>
              </div>
            )}

            {/* Response Content View */}
            <div className="p-4 flex-1 bg-[#0B0D12] overflow-x-auto text-xs font-mono">
              {loading ? (
                <div className="h-64 flex flex-col items-center justify-center text-[#6B7280] space-y-3">
                  <div className="h-5 w-5 animate-spin rounded-full border-2 border-[#818CF8] border-t-transparent" />
                  <span>Executing HTTP {method} request...</span>
                </div>
              ) : responseStatus === null ? (
                <div className="h-64 flex flex-col items-center justify-center text-center text-[#6B7280] space-y-2">
                  <Terminal className="w-8 h-8 text-[#252A35]" />
                  <p className="text-xs text-[#9CA3AF]">
                    Click &quot;Send Request&quot; to execute this call
                  </p>
                  <p className="text-[11px] text-[#6B7280] max-w-xs">
                    Your request will hit our live mock server and display status, latency, headers, and payload.
                  </p>
                </div>
              ) : responseView === 'body' ? (
                <pre className="m-0 text-[#ECEFF4] leading-relaxed">
                  <code>{responseData}</code>
                </pre>
              ) : (
                <div className="space-y-1.5">
                  {Object.entries(responseHeaders).map(([k, v]) => (
                    <div key={k} className="flex gap-2">
                      <span className="text-[#818CF8] select-none">{k}:</span>
                      <span className="text-[#9CA3AF]">{v}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Response Footer Bar */}
            <div className="border-t border-[#252A35] bg-[#0D1016] px-3.5 py-2 flex items-center justify-between text-[11px] text-[#6B7280]">
              <span>Verified sandbox runtime</span>
              <span>Content-Type: application/json</span>
            </div>
          </div>
        </div>

        {/* History Modal / Drawer */}
        {historyOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div
              className="fixed inset-0 bg-[#0B0D12]/80 backdrop-blur-sm"
              onClick={() => setHistoryOpen(false)}
            />
            <div className="relative w-full max-w-lg rounded-lg border border-[#252A35] bg-[#10131A] p-5 shadow-2xl z-10 space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-[#252A35]">
                <div className="flex items-center gap-2">
                  <History className="w-4 h-4 text-[#818CF8]" />
                  <h3 className="text-sm font-semibold text-[#ECEFF4]">Request History</h3>
                </div>
                <button
                  onClick={() => setHistoryOpen(false)}
                  className="text-xs text-[#6B7280] hover:text-[#ECEFF4]"
                >
                  Close
                </button>
              </div>

              {history.length === 0 ? (
                <div className="py-8 text-center text-xs text-[#6B7280]">
                  No requests sent yet.
                </div>
              ) : (
                <div className="max-h-72 overflow-y-auto space-y-2">
                  {history.map((item) => (
                    <div
                      key={item.id}
                      onClick={() => {
                        setUrl(item.url);
                        setMethod(item.method);
                        setHistoryOpen(false);
                      }}
                      className="p-2.5 rounded border border-[#252A35] bg-[#0D1016] hover:bg-[#151923] flex items-center justify-between cursor-pointer transition-colors"
                    >
                      <div className="flex items-center gap-2 overflow-hidden">
                        <MethodBadge method={item.method} size="sm" />
                        <span className="font-mono text-xs text-[#ECEFF4] truncate">
                          {item.url}
                        </span>
                      </div>
                      <div className="flex items-center gap-2 font-mono text-[11px] text-[#6B7280]">
                        <span className={item.status >= 400 ? 'text-[#F87171]' : 'text-[#4ADE80]'}>
                          {item.status}
                        </span>
                        <span>{item.timeMs}ms</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default function PlaygroundPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen bg-[#0B0D12] flex items-center justify-center text-xs text-[#9CA3AF]">
          Loading API Playground...
        </div>
      }
    >
      <PlaygroundContent />
    </Suspense>
  );
}
