'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import {
  Activity,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Radio,
  Server,
  RefreshCw,
  ShieldCheck,
  ChevronRight,
  Info
} from 'lucide-react';
import { STATUS_COMPONENTS, STATUS_INCIDENTS, getUptimeHistory, ServiceComponent } from '@/data/status';

export default function StatusPage() {
  const [uptimeDays] = useState(getUptimeHistory());
  const [testingPing, setTestingPing] = useState(false);
  const [livePingResult, setLivePingResult] = useState<{
    latencyMs: number;
    status: string;
    serverTime: string;
  } | null>(null);

  const handleTestPing = async () => {
    setTestingPing(true);
    const start = performance.now();
    try {
      const res = await fetch('/api/v1/utilities/ping');
      const data = await res.json();
      const elapsed = Math.round(performance.now() - start);
      setLivePingResult({
        latencyMs: elapsed,
        status: data.status || 'ok',
        serverTime: data.serverTime || new Date().toISOString()
      });
    } catch {
      setLivePingResult({
        latencyMs: 0,
        status: 'error',
        serverTime: new Date().toISOString()
      });
    } finally {
      setTestingPing(false);
    }
  };

  const getStatusBadge = (status: ServiceComponent['status']) => {
    switch (status) {
      case 'operational':
        return (
          <span className="inline-flex items-center gap-1.5 text-xs text-[#4ADE80]">
            <span className="h-1.5 w-1.5 rounded-full bg-[#4ADE80]" />
            <span>Operational</span>
          </span>
        );
      case 'degraded':
        return (
          <span className="inline-flex items-center gap-1.5 text-xs text-[#FBBF24]">
            <span className="h-1.5 w-1.5 rounded-full bg-[#FBBF24]" />
            <span>Degraded Performance</span>
          </span>
        );
      case 'outage':
        return (
          <span className="inline-flex items-center gap-1.5 text-xs text-[#F87171]">
            <span className="h-1.5 w-1.5 rounded-full bg-[#F87171]" />
            <span>Major Outage</span>
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1.5 text-xs text-[#9CA3AF]">
            <span className="h-1.5 w-1.5 rounded-full bg-[#9CA3AF]" />
            <span>Maintenance</span>
          </span>
        );
    }
  };

  return (
    <div className="min-h-screen bg-[#0B0D12]">
      {/* Header */}
      <div className="border-b border-[#252A35] bg-[#10131A] py-8">
        <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 text-xs font-mono text-[#4ADE80] mb-1">
                <Activity className="w-3.5 h-3.5" />
                <span>Service Health & Infrastructure Telemetry</span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-semibold tracking-tight text-[#ECEFF4]">
                API System Status
              </h1>
              <p className="mt-1 text-xs sm:text-sm text-[#9CA3AF]">
                Real-time operational health, 90-day uptime records, and incident disclosures.
              </p>
            </div>

            <button
              onClick={handleTestPing}
              disabled={testingPing}
              className="self-start sm:self-auto inline-flex items-center gap-2 px-3 py-1.5 rounded border border-[#252A35] bg-[#151923] hover:bg-[#1f2432] text-xs font-medium text-[#ECEFF4] transition-colors cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 text-[#818CF8] ${testingPing ? 'animate-spin' : ''}`} />
              <span>{testingPing ? 'Measuring...' : 'Test Live Gateway'}</span>
            </button>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-5xl px-4 py-8 sm:px-6 lg:px-8 space-y-8">
        {/* Simulation Notice Disclaimer */}
        <div className="rounded-lg border border-[#252A35] bg-[#151923]/60 p-4 flex items-start gap-3 text-xs text-[#9CA3AF]">
          <Info className="w-4 h-4 text-[#818CF8] shrink-0 mt-0.5" />
          <div className="leading-relaxed">
            <span className="font-semibold text-[#ECEFF4] mr-1">Demonstration Notice:</span>
            Component metrics and historic outage logs represent a simulated telemetry dataset. The &quot;Test Live Gateway&quot; button runs a real diagnostic ping against our local server instance.
          </div>
        </div>

        {/* Live Ping Benchmark Card */}
        {livePingResult && (
          <div className="rounded-lg border border-[#4ADE80]/30 bg-[#10131A] p-4 text-xs font-mono flex flex-wrap items-center justify-between gap-4 animate-in fade-in">
            <div className="flex items-center gap-3">
              <span className="h-2 w-2 rounded-full bg-[#4ADE80] animate-ping" />
              <div>
                <span className="text-[#ECEFF4] font-semibold">Live Gateway Response Verified</span>
                <div className="text-[11px] text-[#6B7280]">
                  Server Timestamp: {livePingResult.serverTime}
                </div>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <span className="text-[#4ADE80] font-semibold">{livePingResult.latencyMs}ms roundtrip</span>
              <span className="text-[#6B7280]">status: {livePingResult.status}</span>
            </div>
          </div>
        )}

        {/* Overall Status Banner */}
        <div className="rounded-lg border border-[#4ADE80]/30 bg-[#10131A] p-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-[#4ADE80]/10 text-[#4ADE80]">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-semibold text-[#ECEFF4]">
                All Core Systems Operational
              </h2>
              <p className="text-xs text-[#9CA3AF]">
                All REST gateways, token signing authorities, and database clusters functioning nominally.
              </p>
            </div>
          </div>

          <div className="hidden sm:block text-right font-mono text-xs text-[#6B7280]">
            <span>Overall Uptime: </span>
            <span className="text-[#4ADE80] font-semibold">99.98%</span>
          </div>
        </div>

        {/* 90-Day Uptime Visualization */}
        <div className="rounded-lg border border-[#252A35] bg-[#10131A] p-5 space-y-4">
          <div className="flex items-center justify-between text-xs">
            <span className="font-semibold text-[#ECEFF4]">
              System Uptime (Past 90 Days)
            </span>
            <span className="font-mono text-[#6B7280]">99.98% Average</span>
          </div>

          {/* Bar Strip */}
          <div className="flex items-center gap-1 h-8">
            {uptimeDays.map((day) => (
              <div
                key={day.date}
                title={`${day.date}: ${day.uptime}% uptime`}
                className={`flex-1 h-full rounded-xs transition-opacity hover:opacity-80 cursor-pointer ${
                  day.status === 'operational'
                    ? 'bg-[#4ADE80]'
                    : day.status === 'degraded'
                    ? 'bg-[#FBBF24]'
                    : 'bg-[#F87171]'
                }`}
              />
            ))}
          </div>

          <div className="flex items-center justify-between text-[11px] font-mono text-[#6B7280]">
            <span>90 days ago</span>
            <span>Today</span>
          </div>
        </div>

        {/* Service Components List */}
        <div className="space-y-3">
          <h3 className="text-sm font-semibold text-[#ECEFF4] tracking-tight">
            Infrastructure Components
          </h3>
          <div className="rounded-lg border border-[#252A35] bg-[#10131A] divide-y divide-[#252A35]">
            {STATUS_COMPONENTS.map((comp) => (
              <div
                key={comp.name}
                className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
              >
                <div>
                  <div className="font-medium text-[#ECEFF4] flex items-center gap-2">
                    <span>{comp.name}</span>
                    <span className="text-[10px] font-mono text-[#6B7280] px-1.5 py-0.2 rounded bg-[#151923] border border-[#252A35]">
                      {comp.category}
                    </span>
                  </div>
                  <p className="mt-0.5 text-[#9CA3AF] text-[11px]">
                    {comp.description}
                  </p>
                </div>

                <div className="flex items-center gap-6 shrink-0 font-mono text-xs">
                  <div className="hidden md:block text-right">
                    <span className="text-[#6B7280] block text-[10px]">LATENCY</span>
                    <span className="text-[#ECEFF4]">{comp.latency}</span>
                  </div>
                  <div className="hidden md:block text-right">
                    <span className="text-[#6B7280] block text-[10px]">UPTIME</span>
                    <span className="text-[#ECEFF4]">{comp.uptime}</span>
                  </div>
                  <div>{getStatusBadge(comp.status)}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Incident History Section */}
        <div className="space-y-4">
          <h3 className="text-sm font-semibold text-[#ECEFF4] tracking-tight">
            Past Incidents & Maintenance Notices
          </h3>

          <div className="space-y-4">
            {STATUS_INCIDENTS.map((inc) => (
              <div
                key={inc.id}
                className="rounded-lg border border-[#252A35] bg-[#10131A] p-5 space-y-3 text-xs"
              >
                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#252A35]/60 pb-3">
                  <div>
                    <h4 className="font-semibold text-[#ECEFF4] text-sm">
                      {inc.title}
                    </h4>
                    <span className="text-[#9CA3AF] text-[11px]">
                      Impact: {inc.impact}
                    </span>
                  </div>

                  <span className="px-2 py-0.5 rounded text-[10px] font-mono uppercase bg-[#151923] text-[#4ADE80] border border-[#4ADE80]/30 font-semibold">
                    {inc.status}
                  </span>
                </div>

                {/* Updates timeline */}
                <div className="space-y-2.5 pt-1">
                  {inc.updates.map((up, idx) => (
                    <div key={idx} className="flex items-start gap-3 text-xs">
                      <span className="font-mono text-[11px] text-[#6B7280] shrink-0 mt-0.5">
                        {up.timestamp.replace('T', ' ').replace('Z', ' UTC')}
                      </span>
                      <div className="leading-relaxed">
                        <span className="font-medium text-[#ECEFF4] mr-2">
                          {up.status}:
                        </span>
                        <span className="text-[#9CA3AF]">{up.message}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
