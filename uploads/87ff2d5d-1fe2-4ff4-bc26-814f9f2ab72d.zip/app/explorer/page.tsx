'use client';

import React, { useState, useMemo } from 'react';
import Link from 'next/link';
import {
  Search,
  Filter,
  Layers,
  Terminal,
  BookOpen,
  ArrowRight,
  ShieldCheck,
  KeyRound,
  ExternalLink,
  X,
  SlidersHorizontal,
  ChevronRight,
  Code
} from 'lucide-react';
import { API_CATEGORIES, API_ENDPOINTS, ApiEndpoint, HttpMethod } from '@/data/endpoints';
import { MethodBadge } from '@/components/ui/MethodBadge';

export default function ApiExplorerPage() {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedMethod, setSelectedMethod] = useState<string>('ALL');
  const [selectedAuth, setSelectedAuth] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedEndpoint, setSelectedEndpoint] = useState<ApiEndpoint | null>(null);

  const methods = ['ALL', 'GET', 'POST', 'PUT', 'DELETE'];
  const authTypes = ['ALL', 'None', 'Bearer Token', 'API Key'];

  // Filtered endpoints calculation
  const filteredEndpoints = useMemo(() => {
    return API_ENDPOINTS.filter((ep) => {
      // Category match
      if (selectedCategory !== 'all' && ep.category !== selectedCategory) {
        return false;
      }
      // Method match
      if (selectedMethod !== 'ALL' && ep.method !== selectedMethod) {
        return false;
      }
      // Auth match
      if (selectedAuth !== 'ALL' && ep.auth !== selectedAuth) {
        return false;
      }
      // Query search
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesTitle = ep.title.toLowerCase().includes(q);
        const matchesPath = ep.path.toLowerCase().includes(q);
        const matchesSummary = ep.summary.toLowerCase().includes(q);
        const matchesTags = ep.tags.some((t) => t.toLowerCase().includes(q));
        if (!matchesTitle && !matchesPath && !matchesSummary && !matchesTags) {
          return false;
        }
      }
      return true;
    });
  }, [selectedCategory, selectedMethod, selectedAuth, searchQuery]);

  return (
    <div className="min-h-screen bg-[#0B0D12]">
      {/* Top Header Bar */}
      <div className="border-b border-[#252A35] bg-[#10131A] py-8">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 text-xs font-mono text-[#818CF8] mb-1">
                <Layers className="w-3.5 h-3.5" />
                <span>API Directory & Spec Registry</span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-semibold tracking-tight text-[#ECEFF4]">
                API Explorer
              </h1>
              <p className="mt-1 text-xs sm:text-sm text-[#9CA3AF]">
                Discover and inspect REST endpoints, query parameters, authorization headers, and schemas.
              </p>
            </div>

            <div className="flex items-center gap-3">
              <span className="text-xs font-mono text-[#6B7280]">
                Showing {filteredEndpoints.length} of {API_ENDPOINTS.length} endpoints
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Container */}
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column: Category Sidebar */}
          <aside className="lg:col-span-3 space-y-6">
            <div className="rounded-lg border border-[#252A35] bg-[#10131A] p-4">
              <div className="text-xs font-mono font-semibold uppercase tracking-wider text-[#6B7280] mb-3 px-1">
                API Categories
              </div>
              <nav className="space-y-1">
                {API_CATEGORIES.map((cat) => {
                  const isSelected = selectedCategory === cat.id;
                  const count = cat.id === 'all' 
                    ? API_ENDPOINTS.length 
                    : API_ENDPOINTS.filter((e) => e.category === cat.id).length;

                  return (
                    <button
                      key={cat.id}
                      onClick={() => setSelectedCategory(cat.id)}
                      className={`w-full flex items-center justify-between px-3 py-2 rounded text-xs font-medium transition-colors cursor-pointer ${
                        isSelected
                          ? 'bg-[#151923] text-[#ECEFF4] border border-[#252A35]'
                          : 'text-[#9CA3AF] hover:text-[#ECEFF4] hover:bg-[#151923]/40'
                      }`}
                    >
                      <span>{cat.name}</span>
                      <span className="text-[11px] font-mono px-1.5 py-0.5 rounded bg-[#0B0D12] text-[#6B7280] border border-[#252A35]">
                        {count}
                      </span>
                    </button>
                  );
                })}
              </nav>
            </div>

            {/* Quick Tip / Sandbox Box */}
            <div className="rounded-lg border border-[#252A35] bg-[#0D1016] p-4 text-xs text-[#9CA3AF] space-y-2">
              <div className="flex items-center gap-2 text-[#818CF8] font-medium">
                <Terminal className="w-3.5 h-3.5" />
                <span>Live Sandbox Active</span>
              </div>
              <p className="text-[11px] leading-relaxed text-[#6B7280]">
                All endpoints can be executed with live mock latency directly inside our Playground tool.
              </p>
              <Link
                href="/playground"
                className="inline-flex items-center gap-1 text-[11px] text-[#818CF8] hover:text-[#67E8F9]"
              >
                <span>Open Playground</span>
                <ArrowRight className="w-3 h-3" />
              </Link>
            </div>
          </aside>

          {/* Right Column: Search, Filters, and Endpoints List */}
          <main className="lg:col-span-9 space-y-6">
            {/* Filter Bar */}
            <div className="rounded-lg border border-[#252A35] bg-[#10131A] p-4 space-y-4">
              {/* Search Row */}
              <div className="relative">
                <Search className="w-4 h-4 text-[#6B7280] absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Filter by title, path (e.g. /users), tag, or keyword..."
                  className="w-full rounded border border-[#252A35] bg-[#0D1016] pl-9 pr-8 py-2 text-xs text-[#ECEFF4] placeholder-[#6B7280] outline-none focus:border-[#818CF8]/60 font-sans"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#6B7280] hover:text-[#ECEFF4]"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              {/* Method and Auth Filter Chips */}
              <div className="flex flex-wrap items-center justify-between gap-4 pt-1 border-t border-[#252A35]/60 text-xs">
                {/* Method filter */}
                <div className="flex items-center gap-1.5">
                  <span className="text-[11px] font-mono text-[#6B7280] mr-1">Method:</span>
                  {methods.map((method) => {
                    const isActive = selectedMethod === method;
                    return (
                      <button
                        key={method}
                        onClick={() => setSelectedMethod(method)}
                        className={`px-2 py-0.5 rounded text-[11px] font-mono uppercase transition-colors cursor-pointer ${
                          isActive
                            ? 'bg-[#151923] text-[#ECEFF4] border border-[#252A35] font-semibold'
                            : 'text-[#6B7280] hover:text-[#9CA3AF]'
                        }`}
                      >
                        {method}
                      </button>
                    );
                  })}
                </div>

                {/* Auth filter */}
                <div className="flex items-center gap-1.5">
                  <span className="text-[11px] font-mono text-[#6B7280] mr-1">Auth:</span>
                  {authTypes.map((auth) => {
                    const isActive = selectedAuth === auth;
                    return (
                      <button
                        key={auth}
                        onClick={() => setSelectedAuth(auth)}
                        className={`px-2 py-0.5 rounded text-[11px] transition-colors cursor-pointer ${
                          isActive
                            ? 'bg-[#151923] text-[#ECEFF4] border border-[#252A35] font-semibold'
                            : 'text-[#6B7280] hover:text-[#9CA3AF]'
                        }`}
                      >
                        {auth}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Endpoints List */}
            {filteredEndpoints.length === 0 ? (
              <div className="rounded-lg border border-[#252A35] bg-[#10131A] p-12 text-center">
                <Search className="w-8 h-8 text-[#6B7280] mx-auto mb-3" />
                <h3 className="text-sm font-medium text-[#ECEFF4]">No matching endpoints found</h3>
                <p className="mt-1 text-xs text-[#6B7280]">
                  Try clearing your search query or reset the method and category filters.
                </p>
                <button
                  onClick={() => {
                    setSelectedCategory('all');
                    setSelectedMethod('ALL');
                    setSelectedAuth('ALL');
                    setSearchQuery('');
                  }}
                  className="mt-4 px-3 py-1.5 rounded border border-[#252A35] bg-[#151923] text-xs text-[#ECEFF4] hover:bg-[#1f2432]"
                >
                  Reset all filters
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                {filteredEndpoints.map((ep) => (
                  <div
                    key={ep.id}
                    className="rounded-lg border border-[#252A35] bg-[#10131A] p-4 hover:border-[#374151] transition-all flex flex-col justify-between group"
                  >
                    <div>
                      {/* Top line: Method, Path, Auth Tag */}
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div className="flex items-center gap-2.5">
                          <MethodBadge method={ep.method} size="sm" />
                          <span className="text-xs font-mono font-medium text-[#ECEFF4] group-hover:text-[#818CF8] transition-colors">
                            {ep.path}
                          </span>
                        </div>

                        <div className="flex items-center gap-2">
                          <span className="inline-flex items-center gap-1 text-[10px] font-mono px-2 py-0.5 rounded bg-[#0B0D12] border border-[#252A35] text-[#9CA3AF]">
                            {ep.auth === 'None' ? (
                              <span>Public</span>
                            ) : (
                              <>
                                <KeyRound className="w-3 h-3 text-[#FBBF24]" />
                                <span>{ep.auth}</span>
                              </>
                            )}
                          </span>

                          <span className="text-[10px] font-mono text-[#6B7280]">
                            {ep.rateLimit}
                          </span>
                        </div>
                      </div>

                      {/* Summary and description */}
                      <p className="mt-2 text-xs text-[#9CA3AF] leading-relaxed">
                        {ep.summary}
                      </p>

                      {/* Parameters preview summary */}
                      <div className="mt-3 flex flex-wrap items-center gap-1.5">
                        <span className="text-[10px] font-mono text-[#6B7280]">Params:</span>
                        {ep.parameters && ep.parameters.length > 0 ? (
                          ep.parameters.map((p) => (
                            <span
                              key={p.name}
                              className={`text-[10px] font-mono px-1.5 py-0.5 rounded border ${
                                p.required
                                  ? 'bg-[#151923] text-[#818CF8] border-[#818CF8]/30'
                                  : 'bg-[#0D1016] text-[#9CA3AF] border-[#252A35]'
                              }`}
                            >
                              {p.name}{p.required ? '*' : ''}
                            </span>
                          ))
                        ) : (
                          <span className="text-[10px] font-mono text-[#6B7280]">none</span>
                        )}

                        {ep.requestBody && (
                          <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-[#151923] text-[#67E8F9] border border-[#67E8F9]/30">
                            body: JSON
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Bottom Action bar */}
                    <div className="mt-4 pt-3 border-t border-[#252A35]/60 flex items-center justify-between text-xs">
                      <button
                        onClick={() => setSelectedEndpoint(ep)}
                        className="inline-flex items-center gap-1 text-[11px] text-[#9CA3AF] hover:text-[#ECEFF4] cursor-pointer"
                      >
                        <Code className="w-3.5 h-3.5 text-[#818CF8]" />
                        <span>Quick Inspect</span>
                      </button>

                      <div className="flex items-center gap-2">
                        <Link
                          href={`/playground?endpoint=${encodeURIComponent(ep.path)}&method=${ep.method}`}
                          className="inline-flex items-center gap-1 px-2.5 py-1 rounded border border-[#252A35] bg-[#151923] text-[11px] font-medium text-[#ECEFF4] hover:bg-[#1f2432] transition-colors"
                        >
                          <Terminal className="w-3 h-3 text-[#4ADE80]" />
                          <span>Try in Playground</span>
                        </Link>

                        <Link
                          href={`/docs?endpoint=${ep.id}`}
                          className="inline-flex items-center gap-1 px-2.5 py-1 rounded border border-[#252A35] bg-[#10131A] text-[11px] font-medium text-[#9CA3AF] hover:text-[#ECEFF4] hover:bg-[#151923] transition-colors"
                        >
                          <BookOpen className="w-3 h-3" />
                          <span>Docs</span>
                        </Link>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </main>
        </div>
      </div>

      {/* Quick Inspect Slide-Over Drawer */}
      {selectedEndpoint && (
        <div className="fixed inset-0 z-50 flex justify-end">
          <div
            className="fixed inset-0 bg-[#0B0D12]/75 backdrop-blur-sm"
            onClick={() => setSelectedEndpoint(null)}
          />

          <div className="relative w-full max-w-xl bg-[#10131A] border-l border-[#252A35] h-full overflow-y-auto p-6 shadow-2xl z-10 space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-[#252A35]">
              <div className="flex items-center gap-2">
                <MethodBadge method={selectedEndpoint.method} size="md" />
                <span className="font-mono text-xs font-semibold text-[#ECEFF4]">
                  {selectedEndpoint.path}
                </span>
              </div>
              <button
                onClick={() => setSelectedEndpoint(null)}
                className="text-[#6B7280] hover:text-[#ECEFF4]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div>
              <h3 className="text-base font-semibold text-[#ECEFF4]">{selectedEndpoint.title}</h3>
              <p className="mt-1 text-xs text-[#9CA3AF] leading-relaxed">
                {selectedEndpoint.description}
              </p>
            </div>

            {/* Parameters Table */}
            {selectedEndpoint.parameters && selectedEndpoint.parameters.length > 0 && (
              <div>
                <div className="text-xs font-mono font-semibold uppercase tracking-wider text-[#6B7280] mb-2">
                  Parameters
                </div>
                <div className="rounded border border-[#252A35] bg-[#0D1016] overflow-hidden text-xs">
                  <table className="w-full text-left font-mono">
                    <thead className="bg-[#151923] text-[#9CA3AF] border-b border-[#252A35] text-[11px]">
                      <tr>
                        <th className="p-2">Name</th>
                        <th className="p-2">In</th>
                        <th className="p-2">Type</th>
                        <th className="p-2">Required</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#252A35]/50 text-[11px] text-[#ECEFF4]">
                      {selectedEndpoint.parameters.map((p) => (
                        <tr key={p.name}>
                          <td className="p-2 text-[#818CF8]">{p.name}</td>
                          <td className="p-2 text-[#6B7280]">{p.in}</td>
                          <td className="p-2 text-[#9CA3AF]">{p.type}</td>
                          <td className="p-2">
                            {p.required ? (
                              <span className="text-[#F87171]">yes</span>
                            ) : (
                              <span className="text-[#6B7280]">no</span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Request Body Example if present */}
            {selectedEndpoint.requestBody && (
              <div>
                <div className="text-xs font-mono font-semibold uppercase tracking-wider text-[#6B7280] mb-2">
                  Sample Request Body
                </div>
                <div className="rounded border border-[#252A35] bg-[#0D1016] p-3 text-xs font-mono text-[#ECEFF4] overflow-x-auto">
                  <pre className="m-0">
                    <code>{JSON.stringify(selectedEndpoint.requestBody.example, null, 2)}</code>
                  </pre>
                </div>
              </div>
            )}

            {/* Response Example */}
            {selectedEndpoint.responses[0] && (
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-mono font-semibold uppercase tracking-wider text-[#6B7280]">
                    Sample Response ({selectedEndpoint.responses[0].label})
                  </span>
                </div>
                <div className="rounded border border-[#252A35] bg-[#0D1016] p-3 text-xs font-mono text-[#ECEFF4] overflow-x-auto max-h-60">
                  <pre className="m-0">
                    <code>{JSON.stringify(selectedEndpoint.responses[0].body, null, 2)}</code>
                  </pre>
                </div>
              </div>
            )}

            {/* Bottom Actions */}
            <div className="pt-4 border-t border-[#252A35] flex items-center justify-between">
              <Link
                href={`/docs?endpoint=${selectedEndpoint.id}`}
                className="text-xs text-[#818CF8] hover:text-[#67E8F9] inline-flex items-center gap-1"
              >
                <span>Full Documentation</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </Link>

              <Link
                href={`/playground?endpoint=${encodeURIComponent(selectedEndpoint.path)}&method=${selectedEndpoint.method}`}
                className="px-3.5 py-1.5 rounded bg-[#818CF8] text-xs font-medium text-[#0B0D12] hover:bg-[#6366F1] transition-colors"
              >
                Test in Playground
              </Link>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
