'use client';

import React, { useState, useEffect, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import Link from 'next/link';
import {
  BookOpen,
  Terminal,
  ShieldCheck,
  KeyRound,
  Copy,
  Check,
  ChevronRight,
  ExternalLink,
  Search,
  Code2,
  Clock,
  Layers,
  ArrowRight,
  AlertCircle
} from 'lucide-react';
import { API_CATEGORIES, API_ENDPOINTS, ApiEndpoint } from '@/data/endpoints';
import { MethodBadge } from '@/components/ui/MethodBadge';
import { CodeSnippetGroup } from '@/components/ui/CodeSnippetGroup';

function DocsContent() {
  const searchParams = useSearchParams();
  const endpointParam = searchParams.get('endpoint');
  const categoryParam = searchParams.get('category');

  // Selected endpoint
  const [activeEndpointId, setActiveEndpointId] = useState<string>(
    endpointParam || 'get-users'
  );
  const [selectedResponseIndex, setSelectedResponseIndex] = useState(0);
  const [searchDocQuery, setSearchDocQuery] = useState('');
  const [copiedUrl, setCopiedUrl] = useState(false);

  useEffect(() => {
    if (endpointParam) {
      setActiveEndpointId(endpointParam);
      setSelectedResponseIndex(0);
    } else if (categoryParam) {
      const match = API_ENDPOINTS.find((e) => e.category === categoryParam);
      if (match) {
        setActiveEndpointId(match.id);
        setSelectedResponseIndex(0);
      }
    }
  }, [endpointParam, categoryParam]);

  const currentEndpoint =
    API_ENDPOINTS.find((e) => e.id === activeEndpointId) || API_ENDPOINTS[0];

  const handleCopyUrl = () => {
    navigator.clipboard.writeText(`https://api.example.com${currentEndpoint.path}`);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 2000);
  };

  // Generate multi-language snippets
  const getSnippets = (ep: ApiEndpoint) => {
    const fullUrl = `https://api.example.com${ep.path}`;
    const authHeader = ep.auth !== 'None' ? '  -H "Authorization: Bearer <TOKEN>" \\\n' : '';

    const curl = `curl -X ${ep.method} "${fullUrl}" \\
${authHeader}  -H "Accept: application/json"${
      ep.requestBody
        ? ` \\\n  -H "Content-Type: application/json" \\\n  -d '${JSON.stringify(ep.requestBody.example)}'`
        : ''
    }`;

    const js = `const response = await fetch("${fullUrl}", {
  method: "${ep.method}",
  headers: {
    "Accept": "application/json",${
      ep.auth !== 'None' ? '\n    "Authorization": "Bearer <TOKEN>",' : ''
    }${
      ep.requestBody ? '\n    "Content-Type": "application/json",' : ''
    }
  },${
    ep.requestBody
      ? `\n  body: JSON.stringify(${JSON.stringify(ep.requestBody.example, null, 2)})`
      : ''
  }
});

const data = await response.json();
console.log(data);`;

    const python = `import requests

url = "${fullUrl}"
headers = {
    "Accept": "application/json",${
      ep.auth !== 'None' ? '\n    "Authorization": "Bearer <TOKEN>",' : ''
    }
}
${
  ep.requestBody
    ? `payload = ${JSON.stringify(ep.requestBody.example, null, 4)}

response = requests.${ep.method.toLowerCase()}(url, json=payload, headers=headers)`
    : `response = requests.${ep.method.toLowerCase()}(url, headers=headers)`
}

print(response.status_code)
print(response.json())`;

    const go = `package main

import (
    "fmt"
    "net/http"
    "io"
)

func main() {
    req, err := http.NewRequest("${ep.method}", "${fullUrl}", nil)
    if err != nil {
        panic(err)
    }
    req.Header.Set("Accept", "application/json")

    client := &http.Client{}
    resp, err := client.Do(req)
    if err != nil {
        panic(err)
    }
    defer resp.Body.Close()

    body, _ := io.ReadAll(resp.Body)
    fmt.Println(string(body))
}`;

    return [
      { language: 'curl', label: 'cURL', code: curl },
      { language: 'javascript', label: 'JavaScript', code: js },
      { language: 'python', label: 'Python', code: python },
      { language: 'go', label: 'Go', code: go },
    ];
  };

  const filteredEndpointsBySearch = API_ENDPOINTS.filter((ep) =>
    ep.title.toLowerCase().includes(searchDocQuery.toLowerCase()) ||
    ep.path.toLowerCase().includes(searchDocQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-[#0B0D12]">
      {/* Top Docs Header */}
      <div className="border-b border-[#252A35] bg-[#10131A] py-6">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 text-xs font-mono text-[#67E8F9] mb-1">
                <BookOpen className="w-3.5 h-3.5" />
                <span>Reference Guide & Schema Specifications</span>
              </div>
              <h1 className="text-2xl font-semibold tracking-tight text-[#ECEFF4]">
                API Documentation
              </h1>
            </div>

            <div className="flex items-center gap-2">
              <Link
                href={`/playground?endpoint=${encodeURIComponent(currentEndpoint.path)}&method=${currentEndpoint.method}`}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded bg-[#818CF8] hover:bg-[#6366F1] text-xs font-semibold text-[#0B0D12] transition-colors"
              >
                <Terminal className="w-3.5 h-3.5" />
                <span>Try in Playground</span>
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Docs Body: 3-column layout (Sidebar, Main content, TOC) */}
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column: Docs Navigation Sidebar */}
          <aside className="lg:col-span-3 space-y-5">
            {/* Search Docs input */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-[#6B7280] absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchDocQuery}
                onChange={(e) => setSearchDocQuery(e.target.value)}
                placeholder="Search documentation..."
                className="w-full rounded border border-[#252A35] bg-[#0D1016] pl-8 pr-3 py-1.5 text-xs text-[#ECEFF4] placeholder-[#6B7280] outline-none focus:border-[#818CF8]/60 font-sans"
              />
            </div>

            {/* General Guides */}
            <div className="rounded-lg border border-[#252A35] bg-[#10131A] p-3 text-xs">
              <div className="text-[11px] font-mono font-semibold uppercase tracking-wider text-[#6B7280] mb-2 px-1">
                Foundations
              </div>
              <div className="space-y-0.5">
                <a
                  href="#overview"
                  className="block px-2.5 py-1.5 rounded text-[#9CA3AF] hover:text-[#ECEFF4] hover:bg-[#151923]/40"
                >
                  Overview & Conventions
                </a>
                <a
                  href="#authentication"
                  className="block px-2.5 py-1.5 rounded text-[#9CA3AF] hover:text-[#ECEFF4] hover:bg-[#151923]/40"
                >
                  Authentication & Keys
                </a>
                <a
                  href="#errors"
                  className="block px-2.5 py-1.5 rounded text-[#9CA3AF] hover:text-[#ECEFF4] hover:bg-[#151923]/40"
                >
                  Errors & Rate Limits
                </a>
              </div>
            </div>

            {/* Endpoints by Category */}
            <div className="rounded-lg border border-[#252A35] bg-[#10131A] p-3 text-xs space-y-4">
              <div className="text-[11px] font-mono font-semibold uppercase tracking-wider text-[#6B7280] px-1">
                Endpoints Registry
              </div>

              {API_CATEGORIES.filter((c) => c.id !== 'all').map((cat) => {
                const endpoints = filteredEndpointsBySearch.filter((e) => e.category === cat.id);
                if (endpoints.length === 0) return null;

                return (
                  <div key={cat.id} className="space-y-1">
                    <div className="text-[11px] font-semibold text-[#818CF8] px-2 py-0.5">
                      {cat.name}
                    </div>
                    {endpoints.map((ep) => {
                      const isActive = ep.id === currentEndpoint.id;
                      return (
                        <button
                          key={ep.id}
                          onClick={() => {
                            setActiveEndpointId(ep.id);
                            setSelectedResponseIndex(0);
                          }}
                          className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded text-left transition-colors cursor-pointer ${
                            isActive
                              ? 'bg-[#151923] text-[#ECEFF4] border border-[#252A35] font-medium'
                              : 'text-[#9CA3AF] hover:text-[#ECEFF4] hover:bg-[#151923]/40'
                          }`}
                        >
                          <span className="truncate pr-2">{ep.title}</span>
                          <MethodBadge method={ep.method} size="sm" />
                        </button>
                      );
                    })}
                  </div>
                );
              })}
            </div>
          </aside>

          {/* Center Column: Detailed Endpoint Documentation */}
          <main className="lg:col-span-7 space-y-8">
            {/* Breadcrumb */}
            <div className="flex items-center gap-1.5 text-xs font-mono text-[#6B7280]">
              <Link href="/docs" className="hover:text-[#ECEFF4]">
                docs
              </Link>
              <ChevronRight className="w-3 h-3" />
              <span>{currentEndpoint.category.toLowerCase()}</span>
              <ChevronRight className="w-3 h-3" />
              <span className="text-[#ECEFF4]">{currentEndpoint.id}</span>
            </div>

            {/* Title & Summary */}
            <div className="space-y-2">
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="text-2xl font-semibold text-[#ECEFF4] tracking-tight">
                  {currentEndpoint.title}
                </h2>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#151923] text-[#818CF8] border border-[#252A35]">
                  v1.4
                </span>
              </div>
              <p className="text-sm text-[#9CA3AF] leading-relaxed">
                {currentEndpoint.description}
              </p>
            </div>

            {/* Endpoint Method & URL Bar */}
            <div className="rounded-md border border-[#252A35] bg-[#10131A] p-3 flex items-center justify-between font-mono text-xs">
              <div className="flex items-center gap-2.5 overflow-hidden">
                <MethodBadge method={currentEndpoint.method} size="md" />
                <span className="text-[#ECEFF4] font-medium truncate">
                  https://api.example.com{currentEndpoint.path}
                </span>
              </div>
              <button
                onClick={handleCopyUrl}
                className="shrink-0 inline-flex items-center gap-1 px-2 py-1 rounded bg-[#151923] border border-[#252A35] text-[#9CA3AF] hover:text-[#ECEFF4] cursor-pointer"
              >
                {copiedUrl ? (
                  <>
                    <Check className="w-3 h-3 text-[#4ADE80]" />
                    <span className="text-[#4ADE80] text-[10px]">Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3 h-3" />
                    <span className="text-[10px]">Copy URL</span>
                  </>
                )}
              </button>
            </div>

            {/* Authentication Spec */}
            <div id="authentication" className="rounded-lg border border-[#252A35] bg-[#10131A] p-4 text-xs space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs font-semibold text-[#ECEFF4]">
                  <KeyRound className="w-3.5 h-3.5 text-[#FBBF24]" />
                  <span>Authentication Requirement</span>
                </div>
                <span className="font-mono text-[11px] text-[#6B7280]">
                  Quota: {currentEndpoint.rateLimit}
                </span>
              </div>

              <p className="text-[#9CA3AF] leading-relaxed">
                {currentEndpoint.auth === 'None' ? (
                  'This endpoint is publicly accessible. No bearer token or API key header is strictly required, although authenticated requests benefit from higher rate limits.'
                ) : (
                  <span>
                    Requires authorization. Pass your token via the standard header:{' '}
                    <code className="text-[#818CF8] bg-[#0D1016] px-1.5 py-0.5 rounded border border-[#252A35] font-mono text-[11px]">
                      Authorization: Bearer &lt;TOKEN&gt;
                    </code>
                  </span>
                )}
              </p>
            </div>

            {/* Parameters Table */}
            {currentEndpoint.parameters && currentEndpoint.parameters.length > 0 && (
              <div id="parameters" className="space-y-3">
                <h3 className="text-sm font-semibold text-[#ECEFF4] tracking-tight">
                  Request Parameters
                </h3>
                <div className="rounded-lg border border-[#252A35] bg-[#10131A] overflow-hidden">
                  <table className="w-full text-left text-xs font-mono">
                    <thead className="bg-[#0D1016] text-[#9CA3AF] border-b border-[#252A35] text-[11px]">
                      <tr>
                        <th className="p-3">Field</th>
                        <th className="p-3">In</th>
                        <th className="p-3">Type</th>
                        <th className="p-3">Requirement</th>
                        <th className="p-3 font-sans">Description</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#252A35]/50 text-[#ECEFF4]">
                      {currentEndpoint.parameters.map((param) => (
                        <tr key={param.name} className="hover:bg-[#151923]/40">
                          <td className="p-3 text-[#818CF8] font-semibold">{param.name}</td>
                          <td className="p-3 text-[#6B7280]">{param.in}</td>
                          <td className="p-3 text-[#9CA3AF]">{param.type}</td>
                          <td className="p-3">
                            {param.required ? (
                              <span className="text-[#F87171] font-sans text-[11px] font-medium">required</span>
                            ) : (
                              <span className="text-[#6B7280] font-sans text-[11px]">optional</span>
                            )}
                          </td>
                          <td className="p-3 font-sans text-xs text-[#9CA3AF] leading-relaxed">
                            {param.description}
                            {param.default && (
                              <span className="block font-mono text-[11px] text-[#6B7280] mt-0.5">
                                default: {param.default}
                              </span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Request Body Specification */}
            {currentEndpoint.requestBody && (
              <div id="request-body" className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-semibold text-[#ECEFF4] tracking-tight">
                    Request Body Payload
                  </h3>
                  <span className="text-[11px] font-mono text-[#67E8F9]">
                    application/json
                  </span>
                </div>

                <div className="rounded-lg border border-[#252A35] bg-[#0D1016] p-4 text-xs font-mono">
                  <pre className="m-0 text-[#ECEFF4] overflow-x-auto">
                    <code>{JSON.stringify(currentEndpoint.requestBody.example, null, 2)}</code>
                  </pre>
                </div>
              </div>
            )}

            {/* Request Code Snippets (Multi-language) */}
            <div id="code-examples" className="space-y-3">
              <h3 className="text-sm font-semibold text-[#ECEFF4] tracking-tight">
                Request Implementation
              </h3>
              <CodeSnippetGroup
                snippets={getSnippets(currentEndpoint)}
                title={currentEndpoint.method}
              />
            </div>

            {/* Response Specification & Status Tabs */}
            <div id="response" className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-semibold text-[#ECEFF4] tracking-tight">
                  Response Examples
                </h3>
                <div className="flex items-center gap-1">
                  {currentEndpoint.responses.map((resp, idx) => (
                    <button
                      key={resp.status}
                      onClick={() => setSelectedResponseIndex(idx)}
                      className={`px-2 py-0.5 text-xs font-mono rounded cursor-pointer transition-colors ${
                        selectedResponseIndex === idx
                          ? 'bg-[#151923] text-[#ECEFF4] border border-[#252A35] font-semibold'
                          : 'text-[#6B7280] hover:text-[#9CA3AF]'
                      }`}
                    >
                      {resp.label}
                    </button>
                  ))}
                </div>
              </div>

              {currentEndpoint.responses[selectedResponseIndex] && (
                <div className="rounded-lg border border-[#252A35] bg-[#0D1016] overflow-hidden text-xs font-mono">
                  <div className="border-b border-[#252A35] bg-[#10131A] px-3.5 py-2 flex items-center justify-between text-[#9CA3AF]">
                    <span className="font-sans text-[11px]">
                      {currentEndpoint.responses[selectedResponseIndex].description}
                    </span>
                    <span className="text-[11px] text-[#6B7280]">
                      HTTP Status {currentEndpoint.responses[selectedResponseIndex].status}
                    </span>
                  </div>
                  <div className="p-4 overflow-x-auto max-h-80 text-[#ECEFF4]">
                    <pre className="m-0">
                      <code>
                        {JSON.stringify(
                          currentEndpoint.responses[selectedResponseIndex].body,
                          null,
                          2
                        )}
                      </code>
                    </pre>
                  </div>
                </div>
              )}
            </div>

            {/* Related Endpoints */}
            <div className="pt-6 border-t border-[#252A35] space-y-3">
              <h4 className="text-xs font-mono font-semibold uppercase tracking-wider text-[#6B7280]">
                Related Endpoints in {currentEndpoint.category}
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {API_ENDPOINTS.filter(
                  (e) => e.category === currentEndpoint.category && e.id !== currentEndpoint.id
                ).slice(0, 4).map((rel) => (
                  <button
                    key={rel.id}
                    onClick={() => {
                      setActiveEndpointId(rel.id);
                      setSelectedResponseIndex(0);
                    }}
                    className="p-3 rounded border border-[#252A35] bg-[#10131A] hover:bg-[#151923] text-left transition-colors cursor-pointer group"
                  >
                    <div className="flex items-center gap-2 mb-1">
                      <MethodBadge method={rel.method} size="sm" />
                      <span className="text-xs font-medium text-[#ECEFF4] group-hover:text-[#818CF8] truncate">
                        {rel.title}
                      </span>
                    </div>
                    <span className="text-[11px] font-mono text-[#6B7280] truncate block">
                      {rel.path}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          </main>

          {/* Right Column: Table of Contents */}
          <aside className="hidden lg:block lg:col-span-2 space-y-3 sticky top-20 text-xs">
            <div className="text-[11px] font-mono uppercase tracking-wider text-[#6B7280] font-semibold">
              On this page
            </div>
            <nav className="space-y-1.5 border-l border-[#252A35] pl-3 text-[#9CA3AF]">
              <a href="#overview" className="block hover:text-[#ECEFF4]">
                Overview
              </a>
              <a href="#authentication" className="block hover:text-[#ECEFF4]">
                Authentication
              </a>
              {currentEndpoint.parameters && currentEndpoint.parameters.length > 0 && (
                <a href="#parameters" className="block hover:text-[#ECEFF4]">
                  Parameters
                </a>
              )}
              {currentEndpoint.requestBody && (
                <a href="#request-body" className="block hover:text-[#ECEFF4]">
                  Request Body
                </a>
              )}
              <a href="#code-examples" className="block hover:text-[#ECEFF4]">
                Code Snippets
              </a>
              <a href="#response" className="block hover:text-[#ECEFF4]">
                Response Schema
              </a>
            </nav>

            <div className="pt-4 mt-4 border-t border-[#252A35]">
              <Link
                href={`/playground?endpoint=${encodeURIComponent(currentEndpoint.path)}&method=${currentEndpoint.method}`}
                className="w-full flex items-center justify-center gap-1.5 py-1.5 rounded border border-[#252A35] bg-[#151923] text-[11px] font-medium text-[#ECEFF4] hover:bg-[#1f2432]"
              >
                <Terminal className="w-3 h-3 text-[#4ADE80]" />
                <span>Test Endpoint</span>
              </Link>
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
}

export default function DocsPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen bg-[#0B0D12] flex items-center justify-center text-xs text-[#9CA3AF]">
          Loading API Documentation...
        </div>
      }
    >
      <DocsContent />
    </Suspense>
  );
}
