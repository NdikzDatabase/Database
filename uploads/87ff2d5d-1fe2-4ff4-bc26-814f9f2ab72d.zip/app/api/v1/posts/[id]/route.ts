import { NextRequest, NextResponse } from 'next/server';
import { initialPosts, PostRecord } from '@/lib/mockDatabase';

const postsStore: PostRecord[] = [...initialPosts];

export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const post = postsStore.find(p => p.id === id || p.slug === id);

  if (!post) {
    return NextResponse.json({
      success: false,
      error: {
        code: 'POST_NOT_FOUND',
        message: `No article found with identifier or slug "${id}".`,
        timestamp: new Date().toISOString()
      }
    }, { status: 404 });
  }

  return NextResponse.json({
    success: true,
    data: post
  }, { status: 200 });
}

export async function DELETE(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const index = postsStore.findIndex(p => p.id === id);

  if (index === -1) {
    return NextResponse.json({
      success: false,
      error: {
        code: 'POST_NOT_FOUND',
        message: `Cannot delete post "${id}".`,
        timestamp: new Date().toISOString()
      }
    }, { status: 404 });
  }

  postsStore.splice(index, 1);

  return NextResponse.json({
    success: true,
    data: {
      id,
      deleted: true,
      timestamp: new Date().toISOString()
    }
  }, { status: 200 });
}
