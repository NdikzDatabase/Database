import { NextRequest, NextResponse } from 'next/server';
import { initialPosts, PostRecord } from '@/lib/mockDatabase';

const postsStore: PostRecord[] = [...initialPosts];

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const tag = searchParams.get('tag')?.toLowerCase();
  const limit = Math.min(20, Math.max(1, parseInt(searchParams.get('limit') || '10', 10)));

  let filtered = [...postsStore];
  if (tag) {
    filtered = filtered.filter(p => p.tag.toLowerCase() === tag);
  }

  const data = filtered.slice(0, limit);

  return NextResponse.json({
    success: true,
    meta: {
      count: data.length,
      total: filtered.length
    },
    data
  }, {
    status: 200,
    headers: {
      'Content-Type': 'application/json',
      'X-Resp-Version': '1.4.0'
    }
  });
}

export async function POST(request: NextRequest) {
  const body = await request.json().catch(() => null);

  if (!body || !body.title || !body.content) {
    return NextResponse.json({
      success: false,
      error: {
        code: 'VALIDATION_FAILED',
        message: 'Both "title" and "content" fields are required.',
        timestamp: new Date().toISOString()
      }
    }, { status: 400 });
  }

  const newPost: PostRecord = {
    id: `pst_${String(postsStore.length + 101)}`,
    title: String(body.title).trim(),
    slug: String(body.title).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''),
    content: String(body.content).trim(),
    author: body.author ? String(body.author).trim() : 'Resp API Contributor',
    tag: body.tag ? String(body.tag).trim() : 'general',
    views: 1,
    publishedAt: new Date().toISOString()
  };

  postsStore.push(newPost);

  return NextResponse.json({
    success: true,
    data: newPost
  }, { status: 201 });
}
