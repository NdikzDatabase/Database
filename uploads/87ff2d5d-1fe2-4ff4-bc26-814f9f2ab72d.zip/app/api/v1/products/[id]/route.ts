import { NextRequest, NextResponse } from 'next/server';
import { initialProducts, ProductRecord } from '@/lib/mockDatabase';

const productsStore: ProductRecord[] = [...initialProducts];

export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const product = productsStore.find(p => p.id === id || p.sku.toLowerCase() === id.toLowerCase());

  if (!product) {
    return NextResponse.json({
      success: false,
      error: {
        code: 'PRODUCT_NOT_FOUND',
        message: `No product found matching ID or SKU "${id}".`,
        timestamp: new Date().toISOString()
      }
    }, { status: 404 });
  }

  return NextResponse.json({
    success: true,
    data: product
  }, { status: 200 });
}
