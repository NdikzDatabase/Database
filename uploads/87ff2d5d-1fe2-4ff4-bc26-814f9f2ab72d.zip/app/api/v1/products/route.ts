import { NextRequest, NextResponse } from 'next/server';
import { initialProducts, ProductRecord } from '@/lib/mockDatabase';

const productsStore: ProductRecord[] = [...initialProducts];

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const category = searchParams.get('category')?.toLowerCase();
  const inStock = searchParams.get('inStock');

  let filtered = [...productsStore];

  if (category) {
    filtered = filtered.filter(p => p.category.toLowerCase() === category);
  }

  if (inStock === 'true') {
    filtered = filtered.filter(p => p.inStock);
  }

  return NextResponse.json({
    success: true,
    meta: {
      total: filtered.length
    },
    data: filtered
  }, {
    status: 200,
    headers: {
      'Content-Type': 'application/json',
      'X-Resp-Version': '1.4.0'
    }
  });
}

export async function POST(request: NextRequest) {
  const body = await request.json().catch(() => null);

  if (!body || !body.name || !body.sku || typeof body.price !== 'number') {
    return NextResponse.json({
      success: false,
      error: {
        code: 'VALIDATION_FAILED',
        message: 'Fields "name", "sku", and numeric "price" are required.',
        timestamp: new Date().toISOString()
      }
    }, { status: 400 });
  }

  const newProduct: ProductRecord = {
    id: `prd_${String(productsStore.length + 901)}`,
    sku: String(body.sku).trim().toUpperCase(),
    name: String(body.name).trim(),
    category: body.category ? String(body.category).trim() : 'general',
    price: Number(body.price),
    currency: 'USD',
    stock: typeof body.stock === 'number' ? body.stock : 10,
    inStock: typeof body.stock === 'number' ? body.stock > 0 : true,
    description: body.description ? String(body.description) : ''
  };

  productsStore.push(newProduct);

  return NextResponse.json({
    success: true,
    data: newProduct
  }, { status: 201 });
}
