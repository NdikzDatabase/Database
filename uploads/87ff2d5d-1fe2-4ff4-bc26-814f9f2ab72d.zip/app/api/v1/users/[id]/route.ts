import { NextRequest, NextResponse } from 'next/server';
import { initialUsers, UserRecord } from '@/lib/mockDatabase';

const usersStore: UserRecord[] = [...initialUsers];

export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const user = usersStore.find(u => u.id === id);

  if (!user) {
    return NextResponse.json({
      success: false,
      error: {
        code: 'USER_NOT_FOUND',
        message: `No active user found with identifier "${id}".`,
        timestamp: new Date().toISOString()
      }
    }, { status: 404 });
  }

  return NextResponse.json({
    success: true,
    data: {
      ...user,
      timezone: 'UTC',
      verified: true,
      lastLoginAt: '2026-10-17T09:30:11Z'
    }
  }, {
    status: 200,
    headers: {
      'Content-Type': 'application/json',
      'X-Resp-Version': '1.4.0'
    }
  });
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const userIndex = usersStore.findIndex(u => u.id === id);

  if (userIndex === -1) {
    return NextResponse.json({
      success: false,
      error: {
        code: 'USER_NOT_FOUND',
        message: `Cannot update non-existent user "${id}".`,
        timestamp: new Date().toISOString()
      }
    }, { status: 404 });
  }

  const body = await request.json().catch(() => ({}));
  const updatedUser = {
    ...usersStore[userIndex],
    ...(body.name ? { name: String(body.name).trim() } : {}),
    ...(body.role ? { role: String(body.role).trim() } : {}),
    updatedAt: new Date().toISOString()
  };

  usersStore[userIndex] = updatedUser;

  return NextResponse.json({
    success: true,
    data: updatedUser
  }, { status: 200 });
}

export async function DELETE(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const userIndex = usersStore.findIndex(u => u.id === id);

  if (userIndex === -1) {
    return NextResponse.json({
      success: false,
      error: {
        code: 'USER_NOT_FOUND',
        message: `Cannot delete non-existent user "${id}".`,
        timestamp: new Date().toISOString()
      }
    }, { status: 404 });
  }

  usersStore.splice(userIndex, 1);

  return NextResponse.json({
    success: true,
    data: {
      id,
      deleted: true,
      timestamp: new Date().toISOString()
    }
  }, { status: 200 });
}
