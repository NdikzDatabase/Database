import { NextRequest, NextResponse } from 'next/server';
import { initialUsers, UserRecord } from '@/lib/mockDatabase';

// In-memory array for demo runtime mutations
const usersStore: UserRecord[] = [...initialUsers];

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10));
  const limit = Math.min(50, Math.max(1, parseInt(searchParams.get('limit') || '10', 10)));
  const role = searchParams.get('role');
  const search = searchParams.get('search')?.toLowerCase();

  let filtered = [...usersStore];

  if (role) {
    filtered = filtered.filter(u => u.role.toLowerCase() === role.toLowerCase());
  }

  if (search) {
    filtered = filtered.filter(u =>
      u.name.toLowerCase().includes(search) || u.email.toLowerCase().includes(search)
    );
  }

  const total = filtered.length;
  const totalPages = Math.ceil(total / limit) || 1;
  const offset = (page - 1) * limit;
  const data = filtered.slice(offset, offset + limit);

  return NextResponse.json({
    success: true,
    meta: {
      page,
      limit,
      total,
      totalPages,
      hasNextPage: page < totalPages,
      hasPrevPage: page > 1
    },
    data
  }, {
    status: 200,
    headers: {
      'Content-Type': 'application/json',
      'X-Resp-Version': '1.4.0',
      'RateLimit-Limit': '120',
      'RateLimit-Remaining': '118',
      'RateLimit-Reset': '52'
    }
  });
}

export async function POST(request: NextRequest) {
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json({
        success: false,
        error: {
          code: 'AUTHENTICATION_REQUIRED',
          message: 'A valid Bearer token is required in the Authorization header.',
          timestamp: new Date().toISOString()
        }
      }, { status: 401 });
    }

    const body = await request.json().catch(() => null);

    if (!body || typeof body !== 'object') {
      return NextResponse.json({
        success: false,
        error: {
          code: 'INVALID_PAYLOAD',
          message: 'Request body must be a valid JSON object.',
          timestamp: new Date().toISOString()
        }
      }, { status: 400 });
    }

    const { name, email, role = 'developer' } = body;

    if (!name || typeof name !== 'string' || name.trim().length < 2) {
      return NextResponse.json({
        success: false,
        error: {
          code: 'VALIDATION_FAILED',
          field: 'name',
          message: 'Field "name" must be a string with at least 2 characters.',
          timestamp: new Date().toISOString()
        }
      }, { status: 400 });
    }

    if (!email || typeof email !== 'string' || !email.includes('@')) {
      return NextResponse.json({
        success: false,
        error: {
          code: 'VALIDATION_FAILED',
          field: 'email',
          message: 'Field "email" must be a valid email address.',
          timestamp: new Date().toISOString()
        }
      }, { status: 400 });
    }

    const newUser: UserRecord = {
      id: `usr_${String(usersStore.length + 1).padStart(3, '0')}`,
      name: name.trim(),
      email: email.trim(),
      role: String(role).trim(),
      tier: 'standard',
      status: 'active',
      createdAt: new Date().toISOString()
    };

    usersStore.push(newUser);

    return NextResponse.json({
      success: true,
      data: newUser
    }, {
      status: 201,
      headers: {
        'Content-Type': 'application/json',
        'X-Resp-Version': '1.4.0'
      }
    });
  } catch {
    return NextResponse.json({
      success: false,
      error: {
        code: 'INTERNAL_SERVER_ERROR',
        message: 'An unexpected processing error occurred.',
        timestamp: new Date().toISOString()
      }
    }, { status: 500 });
  }
}
