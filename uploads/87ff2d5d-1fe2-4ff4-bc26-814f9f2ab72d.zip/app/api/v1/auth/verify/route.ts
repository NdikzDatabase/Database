import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  const authHeader = request.headers.get('authorization');

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return NextResponse.json({
      success: false,
      error: {
        code: 'TOKEN_MISSING',
        message: 'No Bearer token found in Authorization header.',
        timestamp: new Date().toISOString()
      }
    }, { status: 401 });
  }

  const token = authHeader.replace('Bearer ', '').trim();

  if (!token || token.length < 8) {
    return NextResponse.json({
      success: false,
      error: {
        code: 'TOKEN_INVALID',
        message: 'The supplied Bearer token signature is invalid or malformed.',
        timestamp: new Date().toISOString()
      }
    }, { status: 401 });
  }

  return NextResponse.json({
    success: true,
    data: {
      active: true,
      tokenPreview: `${token.substring(0, 11)}...`,
      clientId: 'client_live_demo_987',
      scopes: ['read:users', 'write:posts', 'read:products'],
      expiresAt: new Date(Date.now() + 3600 * 1000).toISOString(),
      issuer: 'https://api.resp.dev/auth',
      environment: 'production-demo'
    }
  }, {
    status: 200,
    headers: {
      'Content-Type': 'application/json',
      'X-Resp-Version': '1.4.0'
    }
  });
}
