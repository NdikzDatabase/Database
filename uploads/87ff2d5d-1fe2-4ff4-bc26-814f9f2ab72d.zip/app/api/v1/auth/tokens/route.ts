import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  const body = await request.json().catch(() => null);

  if (!body || !body.clientId || !body.clientSecret) {
    return NextResponse.json({
      success: false,
      error: {
        code: 'MISSING_CREDENTIALS',
        message: 'Both "clientId" and "clientSecret" must be provided in the JSON body.',
        timestamp: new Date().toISOString()
      }
    }, { status: 400 });
  }

  // Simulate token creation for valid demo client credentials
  const scopes = Array.isArray(body.scopes) && body.scopes.length > 0 
    ? body.scopes 
    : ['read:users', 'read:posts', 'read:products'];

  const randomHash = Math.random().toString(36).substring(2, 12) + Math.random().toString(36).substring(2, 12);
  const token = `rsp_tok_${randomHash}`;

  return NextResponse.json({
    success: true,
    data: {
      tokenType: 'Bearer',
      accessToken: token,
      expiresIn: 3600,
      scopes,
      issuedAt: new Date().toISOString(),
      clientId: body.clientId
    }
  }, {
    status: 200,
    headers: {
      'Content-Type': 'application/json',
      'X-Resp-Version': '1.4.0',
      'Cache-Control': 'no-store'
    }
  });
}
