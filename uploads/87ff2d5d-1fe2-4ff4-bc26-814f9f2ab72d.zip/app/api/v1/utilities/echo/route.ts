import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  const headersObj: Record<string, string> = {};
  request.headers.forEach((value, key) => {
    // Exclude internal sensitive proxy headers
    if (!key.startsWith('x-forwarded-for-internal')) {
      headersObj[key] = value;
    }
  });

  const body = await request.json().catch(() => null);

  return NextResponse.json({
    success: true,
    echo: {
      method: 'POST',
      url: request.nextUrl.pathname,
      query: Object.fromEntries(request.nextUrl.searchParams.entries()),
      headers: headersObj,
      body: body ?? null,
      receivedAt: new Date().toISOString()
    }
  }, {
    status: 200,
    headers: {
      'Content-Type': 'application/json',
      'X-Resp-Version': '1.4.0'
    }
  });
}
