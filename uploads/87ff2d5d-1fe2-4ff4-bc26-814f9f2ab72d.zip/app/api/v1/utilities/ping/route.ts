import { NextResponse } from 'next/server';

export async function GET() {
  const start = Date.now();

  return NextResponse.json({
    success: true,
    status: 'ok',
    pong: true,
    serverTime: new Date().toISOString(),
    region: 'sin1-sg',
    version: '1.4.0',
    uptimeSeconds: Math.floor(process.uptime()),
    diagnostics: {
      memoryUsageMb: Math.round(process.memoryUsage().heapUsed / 1024 / 1024),
      nodeVersion: process.version,
      executionMs: Date.now() - start
    }
  }, {
    status: 200,
    headers: {
      'Content-Type': 'application/json',
      'X-Resp-Version': '1.4.0',
      'X-Response-Time': `${Date.now() - start}ms`
    }
  });
}
