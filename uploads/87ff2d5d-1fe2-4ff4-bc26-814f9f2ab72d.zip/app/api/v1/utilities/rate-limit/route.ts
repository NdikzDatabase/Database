import { NextResponse } from 'next/server';

export async function GET() {
  const resetEpoch = Math.floor(Date.now() / 1000) + 48;

  return NextResponse.json({
    success: true,
    quota: {
      limit: 120,
      remaining: 114,
      resetInSeconds: 48,
      resetEpoch,
      tier: 'developer-standard',
      burstAllowance: 180
    }
  }, {
    status: 200,
    headers: {
      'Content-Type': 'application/json',
      'X-Resp-Version': '1.4.0',
      'RateLimit-Limit': '120',
      'RateLimit-Remaining': '114',
      'RateLimit-Reset': '48'
    }
  });
}
