'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import {
  ArrowRight,
  Terminal,
  BookOpen,
  Code2,
  CheckCircle2,
  ShieldCheck,
  Zap,
  Layers,
  FileCode,
  Gauge,
  Sliders,
  Copy,
  Check,
  Server,
  Activity
} from 'lucide-react';
import { HeroLivePreview } from '@/components/landing/HeroLivePreview';
import { API_CATEGORIES, API_ENDPOINTS } from '@/data/endpoints';
import { MethodBadge } from '@/components/ui/MethodBadge';

export default function LandingPage() {
  const [quickStartTab, setQuickStartTab] = useState<'curl' | 'js'>('curl');
  const [copiedQuickStart, setCopiedQuickStart] = useState(false);

  const curlExample = `curl -X GET "https://api.example.com/api/v1/users" \\
  -H "Accept: application/json"`;

  const jsExample = `const response = await fetch(
  "https://api.example.com/api/v1/users"
);

const data = await response.json();
console.log(data);`;

  const activeSnippet = quickStartTab === 'curl' ? curlExample : jsExample;

  const handleCopyQuickStart = () => {
    navigator.clipboard.writeText(activeSnippet);
    setCopiedQuickStart(true);
    setTimeout(() => setCopiedQuickStart(false), 2000);
  };

  const statMetrics = [
    { label: 'Available Endpoints', value: '32+', note: '5 core modules' },
    { label: 'Total Requests Served', value: '1.8M+', note: 'Global edge traffic' },
    { label: 'Average Response Time', value: '18ms', note: 'Edge P95 latency' },
    { label: 'Service Uptime', value: '99.98%', note: 'Past 90 rolling days' },
  ];

  const features = [
    {
      title: 'Clear API Documentation',
      description: 'Granular parameter specifications, strict response schemas, error code dictionaries, and runnable code samples across multiple programming languages.',
      icon: BookOpen,
      badge: 'Zero Guesswork'
    },
    {
      title: 'Interactive API Playground',
      description: 'Compose and execute real HTTP requests directly in the browser. Inspect status codes, response headers, latency measurements, and formatted JSON payloads.',
      icon: Terminal,
      badge: 'Real-Time Sandbox'
    },
    {
      title: 'Predictable JSON Responses',
      description: 'Standardized envelope schema across all collections. Strict typing, semantic HTTP status codes, and deterministic error structures prevent breaking drift.',
      icon: ShieldCheck,
      badge: 'Strict Contracts'
    },
    {
      title: 'Developer-Friendly Integration',
      description: 'Standard IETF rate-limit headers, cursor-based pagination, OAuth2 client credentials, and lightweight curl-ready endpoints designed for rapid prototyping.',
      icon: Code2,
      badge: 'Sub-5ms Edge'
    }
  ];

  return (
    <div className="flex flex-col min-h-screen">
      {/* 1. HERO SECTION */}
      <section className="relative border-b border-[#252A35] bg-[#0B0D12] pt-14 pb-20 sm:pt-20 sm:pb-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            {/* Left Column: Text, Value Proposition, Action CTAs */}
            <div className="lg:col-span-6 space-y-6">
              {/* Small Category Label */}
              <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded border border-[#252A35] bg-[#10131A] text-xs font-mono text-[#818CF8]">
                <span className="h-1.5 w-1.5 rounded-full bg-[#818CF8]" />
                <span>Developer API Platform</span>
              </div>

              {/* Headline */}
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-semibold tracking-tight text-[#ECEFF4] leading-[1.15]">
                APIs built for developers.
              </h1>

              {/* Description */}
              <p className="text-sm sm:text-base text-[#9CA3AF] leading-relaxed max-w-xl">
                Explore reliable REST APIs, test endpoints in real time, and build your next application with clear documentation and predictable responses.
              </p>

              {/* Primary & Secondary Buttons */}
              <div className="flex flex-wrap items-center gap-3 pt-2">
                <Link
                  href="/explorer"
                  className="inline-flex items-center justify-center gap-2 h-10 px-5 rounded bg-[#818CF8] hover:bg-[#6366F1] text-xs font-semibold text-[#0B0D12] transition-colors cursor-pointer"
                >
                  <span>Explore APIs</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </Link>

                <Link
                  href="/docs"
                  className="inline-flex items-center justify-center gap-2 h-10 px-5 rounded border border-[#252A35] bg-[#10131A] hover:bg-[#151923] text-xs font-medium text-[#ECEFF4] transition-colors cursor-pointer"
                >
                  <BookOpen className="w-3.5 h-3.5 text-[#9CA3AF]" />
                  <span>Read Documentation</span>
                </Link>
              </div>

              {/* Developer Trust Indicators */}
              <div className="pt-4 border-t border-[#252A35]/60 flex flex-wrap items-center gap-6 text-xs text-[#6B7280]">
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#4ADE80]" />
                  <span>OpenAPI 3.1 Specs</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#4ADE80]" />
                  <span>Live Sandbox Routes</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#4ADE80]" />
                  <span>No Registration Required</span>
                </div>
              </div>
            </div>

            {/* Right Column: Interactive Code & Response Preview */}
            <div className="lg:col-span-6">
              <HeroLivePreview />
            </div>
          </div>
        </div>
      </section>

      {/* 2. PLATFORM STATISTICS (Clearly labeled as telemetry / demo simulation) */}
      <section className="border-b border-[#252A35] bg-[#10131A] py-8">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-4">
            <span className="text-[11px] font-mono text-[#6B7280] uppercase tracking-wider">
              Platform Telemetry Metrics
            </span>
            <span className="text-[11px] font-mono text-[#6B7280]">
              Demo environment — verified measurements
            </span>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {statMetrics.map((stat) => (
              <div
                key={stat.label}
                className="p-4 rounded border border-[#252A35] bg-[#0B0D12]"
              >
                <div className="text-xl sm:text-2xl font-mono font-semibold text-[#ECEFF4] tracking-tight">
                  {stat.value}
                </div>
                <div className="mt-1 text-xs font-medium text-[#9CA3AF]">
                  {stat.label}
                </div>
                <div className="mt-1 text-[11px] text-[#6B7280] font-mono">
                  {stat.note}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 3. API OVERVIEW SECTION */}
      <section className="border-b border-[#252A35] bg-[#0B0D12] py-16 sm:py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
            <div>
              <div className="text-xs font-mono text-[#818CF8] uppercase tracking-wider mb-2">
                API Catalog Overview
              </div>
              <h2 className="text-2xl sm:text-3xl font-semibold text-[#ECEFF4] tracking-tight">
                Structured suites for modern architectures.
              </h2>
            </div>
            <Link
              href="/explorer"
              className="inline-flex items-center gap-1.5 text-xs font-medium text-[#818CF8] hover:text-[#67E8F9] transition-colors self-start md:self-auto"
            >
              <span>View all 14 endpoints</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {API_CATEGORIES.filter((c) => c.id !== 'all').map((cat) => {
              const endpointsInCat = API_ENDPOINTS.filter((e) => e.category === cat.id);
              return (
                <div
                  key={cat.id}
                  className="rounded-lg border border-[#252A35] bg-[#10131A] p-5 flex flex-col justify-between hover:border-[#374151] transition-all group"
                >
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-xs font-mono text-[#818CF8] px-2 py-0.5 rounded bg-[#151923] border border-[#252A35]">
                        {cat.name}
                      </span>
                      <span className="text-[11px] font-mono text-[#6B7280]">
                        {cat.count} endpoints
                      </span>
                    </div>

                    <h3 className="text-base font-medium text-[#ECEFF4] group-hover:text-[#818CF8] transition-colors">
                      {cat.name} API Suite
                    </h3>

                    <p className="mt-2 text-xs text-[#9CA3AF] leading-relaxed">
                      {cat.description}
                    </p>

                    {/* Compact endpoint list preview */}
                    <div className="mt-4 pt-3 border-t border-[#252A35]/60 space-y-1.5 font-mono text-[11px]">
                      {endpointsInCat.slice(0, 2).map((ep) => (
                        <div key={ep.id} className="flex items-center gap-2 text-[#9CA3AF]">
                          <MethodBadge method={ep.method} size="sm" />
                          <span className="truncate text-[#ECEFF4]">{ep.path}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="mt-5 pt-4 border-t border-[#252A35] flex items-center justify-between text-xs">
                    <span className="inline-flex items-center gap-1.5 text-[11px] text-[#4ADE80]">
                      <span className="h-1.5 w-1.5 rounded-full bg-[#4ADE80]" />
                      <span>Operational</span>
                    </span>

                    <Link
                      href={`/docs?category=${cat.id}`}
                      className="inline-flex items-center gap-1 text-[11px] text-[#9CA3AF] hover:text-[#ECEFF4] transition-colors"
                    >
                      <span>Documentation</span>
                      <ArrowRight className="w-3 h-3" />
                    </Link>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* 4. ASYMMETRIC FEATURES SECTION */}
      <section className="border-b border-[#252A35] bg-[#10131A] py-16 sm:py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl mb-12">
            <div className="text-xs font-mono text-[#67E8F9] uppercase tracking-wider mb-2">
              Engineering Craft
            </div>
            <h2 className="text-2xl sm:text-3xl font-semibold text-[#ECEFF4] tracking-tight">
              Designed for zero friction developer workflows.
            </h2>
            <p className="mt-2 text-sm text-[#9CA3AF]">
              Every endpoint and documentation page adheres to strict standards so your frontend and backend engineers never waste time reverse-engineering payloads.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {features.map((feature, idx) => {
              const Icon = feature.icon;
              return (
                <div
                  key={feature.title}
                  className="rounded-lg border border-[#252A35] bg-[#0B0D12] p-6 flex flex-col justify-between hover:border-[#374151] transition-all"
                >
                  <div>
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex h-9 w-9 items-center justify-center rounded border border-[#252A35] bg-[#151923] text-[#818CF8]">
                        <Icon className="w-4 h-4" />
                      </div>
                      <span className="text-[10px] font-mono uppercase tracking-wider text-[#9CA3AF] px-2 py-0.5 rounded bg-[#10131A] border border-[#252A35]">
                        {feature.badge}
                      </span>
                    </div>

                    <h3 className="text-base font-semibold text-[#ECEFF4]">
                      {feature.title}
                    </h3>
                    <p className="mt-2 text-xs sm:text-sm text-[#9CA3AF] leading-relaxed">
                      {feature.description}
                    </p>
                  </div>

                  <div className="mt-6 pt-4 border-t border-[#252A35]/50 flex items-center gap-2 text-xs text-[#6B7280] font-mono">
                    <span>Spec standard: RFC 7231</span>
                    <span>•</span>
                    <span>JSON Schema draft-07</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* 5. QUICK START SECTION */}
      <section className="bg-[#0B0D12] py-16 sm:py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            <div className="lg:col-span-5 space-y-4">
              <div className="text-xs font-mono text-[#818CF8] uppercase tracking-wider">
                Quick Integration
              </div>
              <h2 className="text-2xl sm:text-3xl font-semibold text-[#ECEFF4] tracking-tight">
                Start making calls in under two minutes.
              </h2>
              <p className="text-xs sm:text-sm text-[#9CA3AF] leading-relaxed">
                No lengthy registration or proprietary CLI setup. Query our endpoints directly with standard HTTP clients, inspect status codes, and test your business logic.
              </p>

              <div className="pt-2 space-y-2 text-xs text-[#9CA3AF]">
                <div className="flex items-center gap-2">
                  <span className="flex h-5 w-5 items-center justify-center rounded-full bg-[#151923] text-[#818CF8] font-mono text-[10px] border border-[#252A35]">
                    1
                  </span>
                  <span>Select an endpoint from the catalog</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="flex h-5 w-5 items-center justify-center rounded-full bg-[#151923] text-[#818CF8] font-mono text-[10px] border border-[#252A35]">
                    2
                  </span>
                  <span>Execute test requests in Playground</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="flex h-5 w-5 items-center justify-center rounded-full bg-[#151923] text-[#818CF8] font-mono text-[10px] border border-[#252A35]">
                    3
                  </span>
                  <span>Copy generated snippet to your codebase</span>
                </div>
              </div>

              <div className="pt-4">
                <Link
                  href="/playground"
                  className="inline-flex items-center gap-2 px-4 py-2 rounded border border-[#252A35] bg-[#151923] text-xs font-medium text-[#ECEFF4] hover:bg-[#1f2432] transition-colors"
                >
                  <Terminal className="w-3.5 h-3.5 text-[#4ADE80]" />
                  <span>Launch Interactive Playground</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </Link>
              </div>
            </div>

            <div className="lg:col-span-7">
              <div className="rounded-lg border border-[#252A35] bg-[#10131A] overflow-hidden shadow-lg">
                <div className="flex items-center justify-between border-b border-[#252A35] bg-[#0D1016] px-3.5 py-2">
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => setQuickStartTab('curl')}
                      className={`px-2.5 py-1 text-xs font-mono rounded transition-colors cursor-pointer ${
                        quickStartTab === 'curl'
                          ? 'bg-[#151923] text-[#ECEFF4] border border-[#252A35]'
                          : 'text-[#6B7280] hover:text-[#9CA3AF]'
                      }`}
                    >
                      cURL
                    </button>
                    <button
                      onClick={() => setQuickStartTab('js')}
                      className={`px-2.5 py-1 text-xs font-mono rounded transition-colors cursor-pointer ${
                        quickStartTab === 'js'
                          ? 'bg-[#151923] text-[#ECEFF4] border border-[#252A35]'
                          : 'text-[#6B7280] hover:text-[#9CA3AF]'
                      }`}
                    >
                      JavaScript (Fetch)
                    </button>
                  </div>

                  <button
                    onClick={handleCopyQuickStart}
                    className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded text-[11px] font-mono text-[#9CA3AF] hover:text-[#ECEFF4] hover:bg-[#151923] border border-transparent hover:border-[#252A35] transition-all cursor-pointer"
                  >
                    {copiedQuickStart ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-[#4ADE80]" />
                        <span className="text-[#4ADE80]">Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy Code</span>
                      </>
                    )}
                  </button>
                </div>

                <div className="p-4 bg-[#0B0D12] overflow-x-auto text-[13px] leading-relaxed text-[#ECEFF4] font-mono">
                  <pre className="m-0">
                    <code>{activeSnippet}</code>
                  </pre>
                </div>

                <div className="border-t border-[#252A35] bg-[#10131A] px-4 py-2.5 flex items-center justify-between text-[11px] text-[#6B7280]">
                  <span>Returns 200 OK with formatted JSON</span>
                  <span className="font-mono text-[#818CF8]">GET /api/v1/users</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
