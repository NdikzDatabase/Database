import type { Metadata } from 'next';
import { Geist, Geist_Mono } from 'next/font/google';
import './globals.css';
import { Navbar } from '@/components/layout/Navbar';
import { Footer } from '@/components/layout/Footer';
import { CommandPalette } from '@/components/CommandPalette';

const geistSans = Geist({
  variable: '--font-geist-sans',
  subsets: ['latin'],
});

const geistMono = Geist_Mono({
  variable: '--font-geist-mono',
  subsets: ['latin'],
});

export const metadata: Metadata = {
  title: 'Resp API — APIs Built for Developers',
  description:
    'Explore reliable REST APIs, test endpoints in real time, and build your next application with clear documentation and predictable responses.',
  keywords: ['REST API', 'Developer Tools', 'API Documentation', 'API Playground', 'Developer Experience'],
  icons: {
    icon: '/favicon.ico',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html
      lang="en"
      className={`${geistSans.variable} ${geistMono.variable} h-full antialiased`}
    >
      <body className="min-h-full flex flex-col bg-[#0B0D12] text-[#ECEFF4] font-sans">
        <Navbar />
        <main className="flex-1 w-full">{children}</main>
        <Footer />
        <CommandPalette />
      </body>
    </html>
  );
}
