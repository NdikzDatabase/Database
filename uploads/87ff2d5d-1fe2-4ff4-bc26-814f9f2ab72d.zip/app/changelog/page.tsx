import React from 'react';
import Link from 'next/link';
import { History, Tag, CheckCircle2, ShieldAlert, Sparkles, Wrench, Bug, ArrowRight } from 'lucide-react';
import { CHANGELOG_DATA } from '@/data/changelog';

export const metadata = {
  title: 'Changelog — Resp API Platform',
  description: 'Version releases, endpoint additions, performance updates, and API contract revisions.',
};

export default function ChangelogPage() {
  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'Features':
        return <Sparkles className="w-3.5 h-3.5 text-[#818CF8]" />;
      case 'Improvements':
        return <Wrench className="w-3.5 h-3.5 text-[#67E8F9]" />;
      case 'Fixes':
        return <Bug className="w-3.5 h-3.5 text-[#FBBF24]" />;
      case 'Security':
        return <ShieldAlert className="w-3.5 h-3.5 text-[#4ADE80]" />;
      default:
        return <CheckCircle2 className="w-3.5 h-3.5 text-[#9CA3AF]" />;
    }
  };

  return (
    <div className="min-h-screen bg-[#0B0D12]">
      {/* Header */}
      <div className="border-b border-[#252A35] bg-[#10131A] py-8">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-2 text-xs font-mono text-[#818CF8] mb-1">
            <History className="w-3.5 h-3.5" />
            <span>Product Release Log</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-semibold tracking-tight text-[#ECEFF4]">
            Changelog
          </h1>
          <p className="mt-1 text-xs sm:text-sm text-[#9CA3AF]">
            Continuous updates, endpoint expansions, performance optimizations, and contract revisions.
          </p>
        </div>
      </div>

      {/* Timeline entries */}
      <div className="mx-auto max-w-4xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="relative border-l border-[#252A35] ml-4 sm:ml-6 pl-6 sm:pl-8 space-y-12">
          {CHANGELOG_DATA.map((entry, index) => (
            <div key={entry.version} className="relative group">
              {/* Timeline marker node */}
              <div
                className={`absolute -left-[31px] sm:-left-[39px] top-1.5 h-4 w-4 rounded-full border-2 border-[#0B0D12] transition-colors ${
                  index === 0
                    ? 'bg-[#818CF8] ring-4 ring-[#818CF8]/20'
                    : 'bg-[#252A35] group-hover:bg-[#818CF8]'
                }`}
              />

              {/* Version & Date header */}
              <div className="flex flex-wrap items-center gap-2.5 mb-2">
                <span className="font-mono text-sm font-semibold text-[#ECEFF4] px-2 py-0.5 rounded bg-[#151923] border border-[#252A35]">
                  {entry.version}
                </span>

                {index === 0 && (
                  <span className="text-[10px] font-mono uppercase tracking-wider text-[#4ADE80] px-2 py-0.5 rounded bg-[#4ADE80]/10 border border-[#4ADE80]/30 font-semibold">
                    Latest
                  </span>
                )}

                <span className="text-xs font-mono text-[#6B7280]">
                  {entry.date}
                </span>
              </div>

              {/* Title & Summary */}
              <h2 className="text-lg font-semibold text-[#ECEFF4] tracking-tight">
                {entry.title}
              </h2>
              <p className="mt-1 text-xs sm:text-sm text-[#9CA3AF] leading-relaxed">
                {entry.summary}
              </p>

              {/* Changes Categorized */}
              <div className="mt-5 space-y-4">
                {entry.changes.map((group) => (
                  <div
                    key={group.category}
                    className="rounded-lg border border-[#252A35] bg-[#10131A] p-4"
                  >
                    <div className="flex items-center gap-2 text-xs font-semibold text-[#ECEFF4] mb-2.5">
                      {getCategoryIcon(group.category)}
                      <span>{group.category}</span>
                    </div>

                    <ul className="space-y-1.5 text-xs text-[#9CA3AF]">
                      {group.items.map((item, i) => (
                        <li key={i} className="flex items-start gap-2 leading-relaxed">
                          <span className="text-[#6B7280] font-mono select-none mt-0.5">—</span>
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
