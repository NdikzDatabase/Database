//========HELO FRIEND========//
global.owner = ["6285141696833"] 
global.namabot = 'kontol Crash V1 Gen 2'
//======================
global.mess = { 
owner: '*waduhh!, lu bukan owner gw bg*',
premium: '*anda bukan user premium*',
succes: '*done bang*'
}
//======================