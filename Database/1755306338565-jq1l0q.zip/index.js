//========HELO FRIEND========//
require('./system/settings');
const { default: makeWASocket, useMultiFileAuthState, DisconnectReason, makeInMemoryStore, jidDecode, proto } = require("@whiskeysockets/baileys");
const pino = require('pino');
const { Boom } = require('@hapi/boom');
const chalk = require('chalk');
const readline = require("readline");
const { smsg, fetchJson, await, sleep } = require('./lib/myfunction');

//======= Anti Mati =======//
process.on('uncaughtException', err => console.error('Uncaught:', err));
process.on('unhandledRejection', err => console.error('Unhandled:', err));

//======================
const store = makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) });
const usePairingCode = true
const question = (text) => {
    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });
    return new Promise((resolve) => {
        rl.question(text, resolve);
    });
};

//======================
async function StartBot() {
    const { state, saveCreds } = await useMultiFileAuthState('./session')
    const conn = makeWASocket({
        logger: pino({ level: "silent" }),
        printQRInTerminal: !usePairingCode,
        auth: state,
        browser: ["Ubuntu", "Chrome", "20.0.04"],
        keepAliveIntervalMs: 30000 // menjaga koneksi tetap hidup
    });

    if (usePairingCode && !conn.authState.creds.registered) {
        console.log(chalk.cyan("-[ 🔗 Time To Pairing! ]"));
        const phoneNumber = await question(chalk.green("-📞 Enter Your Number Phone::\n"));
        const code = await conn.requestPairingCode(phoneNumber.trim(), "HELOBANG");
        console.log(chalk.blue(`-✅ Pairing Code: `) + chalk.magenta.bold(code));
    }

    conn.public = false

    conn.ev.on("connection.update", async (update) => {
        const { connection, lastDisconnect } = update;
        if (connection === "close") {
            const reason = new Boom(lastDisconnect?.error)?.output?.statusCode;
            const reconnect = () => {
                console.log(chalk.yellow("[!] Reconnecting..."));
                setTimeout(StartBot, 3000); // delay reconnect
            };
            const reasons = {
                [DisconnectReason.badSession]: "Bad Session, hapus session dan scan ulang!",
                [DisconnectReason.connectionClosed]: "Koneksi tertutup, mencoba menghubungkan ulang...",
                [DisconnectReason.connectionLost]: "Koneksi terputus dari server, menghubungkan ulang...",
                [DisconnectReason.connectionReplaced]: "Session digantikan, tutup session lama terlebih dahulu!",
                [DisconnectReason.loggedOut]: "Perangkat keluar, silakan scan ulang!",
                [DisconnectReason.restartRequired]: "Restart diperlukan, memulai ulang...",
                [DisconnectReason.timedOut]: "Koneksi timeout, menghubungkan ulang..."
            };
            console.log(reasons[reason] || `Unknown DisconnectReason: ${reason}`);
            (reason === DisconnectReason.badSession || reason === DisconnectReason.connectionReplaced)
                ? StartBot()
                : reconnect();
        }

        if (connection === "open") {
            let cnnc = `Script Berhasil Tersambung.`;
            conn.sendMessage("62881010916645@s.whatsapp.net", { text: cnnc });
            await console.clear()
            console.log(chalk.red.bold("-[ WhatsApp Terhubung! ]"));
        }
    });

    conn.ev.on("messages.upsert", async ({ messages, type }) => {
        try {
            const msg = messages[0] || messages[messages.length - 1];
            if (type !== "notify") return;
            if (!msg?.message) return;
            if (msg.key && msg.key.remoteJid == "status@broadcast") return;
            const m = smsg(conn, msg, store);
            require(`./case`)(conn, m, msg, store);
        } catch (err) {
            console.log((err));
        }
    });

    conn.decodeJid = (jid) => {
        if (!jid) return jid;
        if (/:\d+@/gi.test(jid)) {
            let decode = jidDecode(jid) || {};
            return decode.user && decode.server && decode.user + '@' + decode.server || jid;
        } else return jid;
    };

    conn.sendText = (jid, text, quoted = '', options) =>
        conn.sendMessage(jid, { text: text, ...options }, { quoted });

    conn.ev.on('contacts.update', update => {
        for (let contact of update) {
            let id = conn.decodeJid(contact.id);
            if (store && store.contacts) {
                store.contacts[id] = { id, name: contact.notify };
            }
        }
    });

    conn.ev.on('creds.update', saveCreds);
    return conn;
}

StartBot()
//======================