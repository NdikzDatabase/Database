require('./system/settings')
const { 
default: baileys, 
proto, 
getContentType, 
generateWAMessage, 
generateWAMessageFromContent, 
generateWAMessageContent,
prepareWAMessageMedia, 
downloadContentFromMessage
} = require("@whiskeysockets/baileys");
const fs = require('fs-extra')
const axios = require('axios')
const util = require('util')
const chalk = require('chalk')
const { getBuffer, getGroupAdmins, getSizeMedia, fetchJson, sleep, isUrl, runtime } = require('./lib/myfunction');
//===============
module.exports = conn = async (conn, m, chatUpdate, store) => {
try {
const body = (
m.mtype === "conversation" ? m.message.conversation :
m.mtype === "imageMessage" ? m.message.imageMessage.caption :
m.mtype === "videoMessage" ? m.message.videoMessage.caption :
m.mtype === "extendedTextMessage" ? m.message.extendedTextMessage.text :
m.mtype === "buttonsResponseMessage" ? m.message.buttonsResponseMessage.selectedButtonId :
m.mtype === "listResponseMessage" ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
m.mtype === "interactiveResponseMessage" ? JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id :
m.mtype === "templateButtonReplyMessage" ? m.message.templateButtonReplyMessage.selectedId :
m.mtype === "messageContextInfo" ?
m.message.buttonsResponseMessage?.selectedButtonId ||
m.message.listResponseMessage?.singleSelectReply.selectedRowId ||
m.message.InteractiveResponseMessage.NativeFlowResponseMessage ||
m.text : "");
const prefix = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><`™©®Δ^βα¦|/\\©^]/.test(body) ? body.match(/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!`™©®Δ^βα¦|/\\©^]/gi) : '.'
const isCmd = body.startsWith(prefix)
const args = isCmd ? body.slice(prefix.length).trim().split(/ +/).slice(1) : [];
 const budy = (typeof m.text == 'string' ? m.text : '')
const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()
const text = q = args.join(" ")//hard
const fatkuns = m.quoted || m;
const quoted = ["buttonsMessage", "templateMessage", "product"].includes(fatkuns.mtype)
? fatkuns[Object.keys(fatkuns)[1] || Object.keys(fatkuns)[0]]
: fatkuns;
//======================
const botNumber = await conn.decodeJid(conn.user.id);
const premuser = JSON.parse(fs.readFileSync("./database/premium.json"));
const isCreator = [botNumber, ...global.owner].map(v => v.replace(/[^0-9]/g, "") + "@s.whatsapp.net").includes(m.sender);
const isPremium = [botNumber, ...global.owner, ...premuser.map(user => user.id.replace(/[^0-9]/g, "") + "@s.whatsapp.net")].includes(m.sender);
if (!conn.public && !isCreator) return;
//======================
const isGroup = m.chat.endsWith("@g.us");
const groupMetadata = isGroup ? await conn.groupMetadata(m.chat).catch(() => ({})) : {};
const participants = groupMetadata.participants || [];
const groupAdmins = participants.filter(v => v.admin).map(v => v.id);
const isBotAdmins = groupAdmins.includes(botNumber);
const isAdmins = groupAdmins.includes(m.sender);
const groupName = groupMetadata.subject || "";
//=====================
if (m.message) {
conn.readMessages([m.key]);
console.log("┏━━━━━━━━━━━━━━━━━━━━━━━=");
console.log(`┃¤ ${chalk.hex("#FFD700").bold("📩 NEW MESSAGE")} ${chalk.hex("#00FFFF").bold(`[${new Date().toLocaleTimeString()}]`)} `);
console.log(`┃¤ ${chalk.hex("#FF69B4")("💌 Dari:")} ${chalk.hex("#FFFFFF")(`${m.pushName} (${m.sender})`)} `);
console.log(`┃¤ ${chalk.hex("#FFA500")("📍 Di:")} ${chalk.hex("#FFFFFF")(`${groupName || "Private Chat"}`)} `);
console.log(`┃¤ ${chalk.hex("#00FF00")("📝 Pesan:")} ${chalk.hex("#FFFFFF")(`${body || m?.mtype || "Unknown"}`)} `);
console.log("┗━━━━━━━━━━━━━━━━━━━━━━━=")}
//======================
// Function Reply
const reply = (teks) => {
conn.sendMessage(m.chat, {
    text: teks,
    contextInfo: {
        mentionedJid: [m.sender],
        forwardingScore: 9999999,
        isForwarded: true,
        "externalAdReply": {
            "showAdAttribution": true,
            "containsAutoReply": true,
            "title": `— ${m.pushName}`,
            "body": `Kriszz Bot | Playground`,
            "previewType": "PHOTO",
            "thumbnailUrl": ``,
            "thumbnail": fs.readFileSync(`./system/media/image.jpg`),
            "sourceUrl": ``
        }
    }
},
{ quoted: m })
}
    
switch (command) {
case "menu": {
reply(`*— All Fitur*
> 々 *tourl*`)
}
break
case "tourl":
case "upload": {
  const fs = require("fs");
  const path = require("path");
  const { fromBuffer } = require("file-type");
  const axios = require("axios");

  const tmpDir = path.join(process.cwd(), "tmp");
  if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir);

  let q = m.quoted || m;
  if (!q) return m.reply("Kirim atau reply media, lalu ketik *.tourl*");
  let mime = (q.msg || q).mimetype || "";
  if (!/image|audio|video|webp/.test(mime)) return m.reply("Media tidak didukung!");
  
  let media = await q.download();
  
  // Batas ukuran 10MB
  if (media.length > 10 * 1024 * 1024) {
    return m.reply("⚠️ Ukuran file terlalu besar! Maksimal 10MB.");
  }

  const { ext } = await fromBuffer(media);
  const filename = `${Date.now()}.${ext}`;
  const filepath = path.join(tmpDir, filename);
  fs.writeFileSync(filepath, media);

  try {
    let githubUrl = await uploadToGitHub(media, filename);
    let size = await Func.formatSize(media.length);
    const msg = `*乂 G I T H U B - U P L O A D E R*
◦ Size : ${size}
◦ URL  : ${githubUrl}`;
    m.reply(msg);

  } catch (err) {
    console.error(err);
    m.reply(err.toString() || "Upload gagal.");
  } finally {
    if (fs.existsSync(filepath)) fs.unlinkSync(filepath);
  }

  async function uploadToGitHub(buffer, filename) {
    const content = buffer.toString("base64");
    const repo = "KriszzTzy/baru";
    const branch = "main";
    try {
      const res = await axios.put(
        `https://api.github.com/repos/${repo}/contents/uploads/${filename}`,
        { message: `Upload ${filename}`, content, branch },
        { headers: { Authorization: `token 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` } }
      );
      return res.data.content.download_url;
    } catch (err) {
      console.error(err.response?.data || err.message);
      throw "Gagal mengupload ke GitHub!";
    }
  }
}
break;

default:
}
if (prefix.startsWith('$')) {
exec(prefix.slice(2), (err, stdout) => {
if(err) return reply(err)
if (stdout) return reply(stdout)
})
}
if (prefix.startsWith(">")) {
if (!isCreator)
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await reply(evaled)
} catch (err) {
reply(String(err))
}
}
} catch (e) {
console.log(e)
}
}

let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})