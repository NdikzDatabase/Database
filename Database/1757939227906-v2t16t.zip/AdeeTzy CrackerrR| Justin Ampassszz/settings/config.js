const fs = require('fs')

const config = {
    owner: "62882005172609",
    botNumber: "6288238532513",
    setPair: "ADETZY21",
    thumbUrl: "https://raw.githubusercontent.com/NdikzDatabase/Database/main/Database/1757922569002-ibet56.jpg",
    session: "sessions",
    status: {
        public: true,
        terminal: true,
        reactsw: false
    },
    message: {
        owner: "no, this is for owners only",
        group: "this is for groups only",
        admin: "this command is for admin only",
        private: "this is specifically for private chat"
    },
    settings: {
        title: "AzrielNoctisV1",
        packname: 'AzrielNoctisV1',
        description: "this script was created by Ditz4You",
        author: 'https://www.kyuurzy.tech',
        footer: "AzrielNoctis |—| DitzOffc"
    },
    newsletter: {
        name: "AzrielNoctis",
        id: "120363401700848273@newsletter"
    },
    socialMedia: {
        YouTube: "https://youtube.com/@justinofficial-id",
        GitHub: "https://github.com/kiuur",
        Telegram: "https://t.me/justinoffc",
        ChannelWA: "https://whatsapp.com/channel/0029VbAVrD86BIEfDK5bdj0r"
    }
}

module.exports = config;

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
