const fs = require('fs')

// >~~~~~~~~~~ Owner Setting ~~~~~~~~~~~< //
global.owner = "6281116601070"
global.ownername = "Gyzen🜲"
global.botname = "Vortunix"
global.footer = "Gyzen"
global.packname = "Gyzen"
// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

global.vercelToken = "5QTW8ibcb0Ds3EO0XACrABSQ" //Your Vercel Token

//——————————[ Manage GitHub ]——————————//
global.githubToken = "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" //Your GitHub Token
global.githubUsername = "jian2345" //Your GitHub Username
// >~~~~~~~~~~ System Setting ~~~~~~~~~~~< //
global.version = "4.0.0 FREE !!!"
global.idch = "120363420016823962@newsletter"
global.prefa = ["", "/"]

// >~~~~~~~~~~ Thumbnail Setting ~~~~~~~~~~~< //
global.thumb = "https://files.catbox.moe/faiw11.jpg"

// >~~~~~~~~~~ Message Setting ~~~~~~~~~~~< //
global.mess = {
owner: "-[ *AKSES DITOLAK* ]-\n> *_Anda Tidak Dapat Menggunakan Fitur Ini Karena Anda Bukanlah Owner!_*", 
ownerprem: "-[ *AKSES DITOLAK* ]-\n> *_Anda Tidak Dapat Menggunakan Fitur Ini Karena Anda Bukanlah Owner & User Premium!_*"
}

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
