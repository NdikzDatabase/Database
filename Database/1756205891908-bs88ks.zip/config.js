module.exports = {
  BOT_TOKEN: "𝗧𝗢𝗞𝗘𝗡_𝗕𝗨𝗬𝗬𝗘𝗥_𝗜𝗦𝗔𝗚𝗜",
  OWNER_ID: ["ID_TELEGRAM"],
};
//@alwayskayzen