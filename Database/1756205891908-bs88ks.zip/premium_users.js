const premiumUsers = [

  { id: '7571435782', expiry: 1684022400000 }, 
  
];

module.exports = premiumUsers;
