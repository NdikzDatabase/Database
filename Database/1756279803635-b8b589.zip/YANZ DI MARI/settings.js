/*
By Yanzz
*/

const settings = {
  token: '7675277719:AAEImWPMCOqbS5Hj8oVQIpx8PdBjanuF3rs',
  adminId: '7972292369', 
  pp: 'https://files.catbox.moe/8kusvh.mp4',
urladmin: 'https://t.me/mangyanzz',
  pp: 'https://files.catbox.moe/jetlw3.jpg',
    //SERVER 1
  domain: 'https://files.catbox.moe/8kusvh.mp4', // domain
  plta: 'ptla_8isdhh7KlEc0Us61QyRne3IhCYTHyLGwjwsHpIzL3uH', //  plta yang sesuai
  pltc: 'ptlc_4AkTB5nFSDoVoXxNiw3nNSWIlvByATywfZLUuZAj0XO', // pltc yang sesuai
  
  //CREATE PANEL
  loc: '1', // Isi dengan lokasi yang diinginkan
  eggs: '15'
};

module.exports = settings;